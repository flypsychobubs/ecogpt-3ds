# EcoGPT for 3DS (UI prototype, v0.4)

Two-screen chat app styled after the EcoGPT iOS app. Top screen: the companion on the top edge, then the conversation.
Bottom screen: input bar, menu, Tools, Voice chat, Camera, Attach, Impact, Badges, Settings.
The backend is a placeholder until EcoGPT's own API is public. Nothing here calls an EcoGPT API yet.

## Build (VS Code)
1. Install devkitPro with the `3ds-dev` group (includes citro2d/citro3d).
2. Open this folder in VS Code, in a terminal where `DEVKITPRO`/`DEVKITARM` are set.
3. Run the "Build 3DSX" task (or `make`). Output: `ecogpt3ds.3dsx`.
4. Copy it to `sdmc:/3ds/` and launch from the Homebrew Launcher.

## SD card folders
- `sdmc:/3ds/ecogpt/config.txt`: connection settings (created on first launch)
- `sdmc:/3ds/ecogpt/stats.txt`: trees, streak, unlock flags, theme
- `sdmc:/3ds/ecogpt/uploads/`: photos and files for the Attach / Images / PDFs pages. Copy files here.
  Camera photos are saved here as `cam-001.bmp`, `cam-002.bmp`, and so on.

## What works now (front end)
- Chat with the connection set in Settings > Connection (unchanged from v0.3)
- Tools grid: Camera, Voice chat, Images, PDFs work. The other tiles show "Needs EcoGPT's API".
- Voice chat page: mic button, listening animation, "Type instead" to return to the keyboard.
  Speech-to-text needs EcoGPT's API, so the mic currently only shows the listening state.
- Camera: take a snapshot on the top-LCD camera, then "Send to Eco". The photo is saved as a BMP in uploads and
  attached to the next message.
- Attach (+ button): take a photo, pick a photo from the SD card, or pick a file from the SD card.
- Badges: full 33-badge sheet in the iOS layout (Forest, Chats, Streaks, Friends, Discover). Tap a badge to see
  its requirement and whether it is unlocked. Friends badges need EcoGPT's API.

## Connection
Set it up inside the app: Settings > Connection (host, API key, optional model, certificate check, Test connection).
It saves to `sdmc:/3ds/ecogpt/config.txt`. No model is required: EcoGPT has no model picker.

## Not wired up yet (needs EcoGPT's API)
- Sending photos and files: `backend_send_attachment()` in `source/backend.c` is a placeholder that refuses.
  When the API exists, implement it there. Until then, attachments stay pending and the message is not sent.
- Speech-to-text for voice chat.
- Friends, global ranking, Library, Apps, Projects, the rest of the Tools grid.

## Controls
- Circle Pad (or D-Pad left/right): move the selection ring, including the companion on the top edge
- Circle Pad / D-Pad up/down on list pages (Tools, Badges, Files): move the focus and the page scrolls with it.
  C-Stick scrolls the list pages directly.
- A: activate what's selected (on the chat page the input bar is selected by default)
- Selecting the companion opens the profile (Impact / Friends). L/R switch tabs there.
- D-Pad Up/Down or C-Stick: scroll the chat
- B: back. X: new chat. Y: profile. Select: menu. Start: exit
- Touch works everywhere too; list pages scroll by dragging. Taps only activate on release, so a drag does not.

## Settings
Companion name, accent color, text size, private chat, reply length, custom instructions, clear chat,
trees planted / reset, connection (host, key, model, TLS check, test), controls, version.

## Notes
- The tree counter is local to this 3DS (1 tree per 200 chats). The streak counts days with a reply, using the
  3DS clock. If the clock is not set, streak badges will not advance.
- Camera code is in `source/camera.c` and follows libctru's camera example. It has not been run on hardware yet.
- The camera preview is a coarse 33x24 block preview, not a full-resolution image.
