#include <3ds.h>
#include <citro2d.h>
#include <ctype.h>
#include <dirent.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include "backend.h"
#include "camera.h"

#define TOP_W 400
#define WRAP_MAX 60
#define MAXL 1400
#define CHATS_PER_TREE 200
#define STATS_FILE "sdmc:/3ds/ecogpt/stats.txt"
#define UPLOAD_DIR "sdmc:/3ds/ecogpt/uploads"
#define VERSION "0.4"

/* top-screen companion, sits on the top edge in the centre */
#define MX 200
#define MY 27
#define MR 21
/* chat viewport on the top screen */
#define CH_TOP 54
#define CH_BOT 226
/* scrolling body on the bottom screen (below the header strip) */
#define BODY_T 36
#define BODY_B 236

#define MAX_FR 72
#define NFILES 40
#define NTOOLS 29
#define NBADGE 33

#define CLR(r, g, b) C2D_Color32(r, g, b, 255)
#define GLA(r, g, b, a) C2D_Color32(r, g, b, a)
#define PI_F 3.14159265f

typedef enum { P_CHAT, P_MENU, P_PROFILE, P_SETTINGS, P_HELP,
               P_TOOLS, P_VOICE, P_CAMERA, P_FILES, P_BADGES, P_ATTACH } Page;
typedef struct { char text[WRAP_MAX + 4]; int role; int w; } DLine;
typedef struct { Config cfg; Msg hist[12]; int n; int test; char reply[MSG_LEN]; int ok; volatile int done; } Job;

/* focusable things */
enum {
    F_NONE = 0,
    F_MASCOT, F_MENU, F_PRIV, F_SUG0, F_SUG1, F_SUG2, F_INPUT, F_SETUP,
    F_ATTACH, F_MIC, F_CHIP,
    F_M_IMPACT, F_M_SETTINGS, F_M_CHAT, F_M_GEAR, F_M_TOOLS, F_M_VOICE,
    F_P_CLOSE, F_P_TAB0, F_P_TAB1, F_P_DROP, F_P_ADD, F_P_BADGES,
    F_V_TALK, F_V_KB,
    F_CAM_SHOT, F_CAM_SEND,
    F_ATT_CAM, F_ATT_PHOTO, F_ATT_FILE,
    F_TOOL_BASE = 100,
    F_BADGE_BASE = 200,
    F_FILE_BASE = 300
};
typedef struct { int id; float x, y, w, h; } FRect;

/* Settings rows */
enum {
    S_NAME = 100, S_ACCENT, S_TEXT, S_PRIVATE, S_REPLY, S_INSTR, S_CLEAR,
    S_TREES, S_RESET, S_TEST, S_HOST, S_KEY, S_MODEL, S_VERIFY, S_CONTROLS, S_VERSION
};
typedef struct { int type; int id; const char *label; } SItem;   /* type 0 = header, 1 = row */
static const SItem SET[] = {
    {0, 0, "Companion"},
    {1, S_NAME, "Name"}, {1, S_ACCENT, "Accent color"},
    {0, 0, "Appearance"},
    {1, S_TEXT, "Text size"},
    {0, 0, "Chat"},
    {1, S_PRIVATE, "Private chat"}, {1, S_REPLY, "Reply length"},
    {1, S_INSTR, "Custom instructions"}, {1, S_CLEAR, "Clear this chat"},
    {0, 0, "Impact"},
    {1, S_TREES, "Trees planted"}, {1, S_RESET, "Reset impact"},
    {0, 0, "Connection"},
    {1, S_TEST, "Test connection"}, {1, S_HOST, "Host"}, {1, S_KEY, "API key"},
    {1, S_MODEL, "Model (optional)"}, {1, S_VERIFY, "Verify certificate"},
    {0, 0, "About"},
    {1, S_CONTROLS, "Controls"}, {1, S_VERSION, "Version"}
};
#define NSET ((int)(sizeof SET / sizeof SET[0]))

/* Palette taken from the iOS screenshots */
static const unsigned char ACC[5][3] = { {52,120,246}, {52,199,89}, {175,82,222}, {255,149,0}, {255,69,120} };
static const char *ACC_N[5] = { "Blue", "Green", "Purple", "Orange", "Pink" };
static const float TSC[3] = { 0.45f, 0.5f, 0.6f };
static const int   TWRAP[3] = { 58, 50, 42 };
static const int   TLH[3] = { 13, 15, 18 };
static const float TCW[3] = { 6.3f, 7.0f, 8.4f };
static const char *TSZ_N[3] = { "Small", "Medium", "Large" };
static const int   RL[3] = { 200, 600, 1200 };
static const char *RL_N[3] = { "Short", "Medium", "Long" };
static const char *SUGG[3] = { "Explain something simply", "Help me write a message", "Plan my week" };

/* ---------- tools (the Tools grid) ---------- */
typedef enum { A_NONE, A_CAMERA, A_VOICE, A_PHOTOS, A_PDFS } ToolAct;
typedef struct { const char *name; ToolAct act; } Tool;
static const Tool TOOLS[NTOOLS] = {
    {"Camera", A_CAMERA}, {"Voice chat", A_VOICE}, {"Images", A_PHOTOS}, {"PDFs", A_PDFS},
    {"Websites", A_NONE}, {"Docs", A_NONE}, {"Slides", A_NONE}, {"Sheets", A_NONE}, {"Humanizer", A_NONE},
    {"Data analysis", A_NONE}, {"Study", A_NONE}, {"Sketch", A_NONE}, {"Math", A_NONE}, {"Search", A_NONE},
    {"Shopping", A_NONE}, {"Maps", A_NONE}, {"Weather", A_NONE}, {"Sports", A_NONE}, {"Notetaker", A_NONE},
    {"Scheduled", A_NONE}, {"Profile", A_NONE}, {"Stories", A_NONE}, {"Game Maker", A_NONE}, {"GitHub", A_NONE},
    {"Outlook", A_NONE}, {"Slack", A_NONE}, {"Notion", A_NONE}, {"Linear", A_NONE}, {"Canvas", A_NONE}
};

/* ---------- badges (33, grouped as in the iOS sheet) ---------- */
enum { M_CHATS, M_STREAK, M_FLAG, M_API };
enum { GL_LEAF, GL_SEED, GL_TREE1, GL_TREE2, GL_TREE3, GL_BUSH, GL_SPROUT, GL_ACORN,
       GL_ORCHARD, GL_GLOBE, GL_CANOPY, GL_BUBBLE, GL_BOOK, GL_LAUREL, GL_DROP, GL_FLAME,
       GL_DROPS, GL_TROPHY, GL_WAVE, GL_MEDAL, GL_PINE, GL_TWO, GL_THREE, GL_RING, GL_HAND,
       GL_PODIUM, GL_BOLT, GL_BULB, GL_FOLDER, GL_CLOCK, GL_BATTERY };
/* local unlock flags, saved in stats.txt */
#define FL_NAME  1
#define FL_VOICE 2
#define FL_CAMERA 4
#define FL_FILE  8
#define FL_INSTR 16
#define FL_PRIV  32

typedef struct { const char *name; int cat; int glyph; unsigned char r, g, b; int metric; int need; const char *cond; } Badge;
static const char *CATS[5] = { "Forest", "Chats", "Streaks", "Friends", "Discover" };
static const Badge BADGES[NBADGE] = {
    /* Forest: by replies received */
    {"Leaf",0,GL_LEAF,96,200,110,M_CHATS,1,"Get your first reply"},
    {"Seed",0,GL_SEED,176,110,60,M_CHATS,10,"Get 10 replies"},
    {"Rooted",0,GL_TREE1,52,180,90,M_CHATS,25,"Get 25 replies"},
    {"Pair",0,GL_TREE2,52,180,90,M_CHATS,50,"Get 50 replies"},
    {"Thicket",0,GL_BUSH,52,199,89,M_CHATS,100,"Get 100 replies"},
    {"Sapling",0,GL_SPROUT,120,220,100,M_CHATS,150,"Get 150 replies"},
    {"Grove",0,GL_TREE3,52,199,89,M_CHATS,200,"Get 200 replies (1 tree)"},
    {"Woodland",0,GL_ACORN,230,150,50,M_CHATS,400,"Get 400 replies (2 trees)"},
    {"Homestead",0,GL_TREE2,52,199,89,M_CHATS,600,"Get 600 replies (3 trees)"},
    {"Orchard",0,GL_ORCHARD,52,199,89,M_CHATS,800,"Get 800 replies (4 trees)"},
    {"Regenerator",0,GL_GLOBE,60,160,255,M_CHATS,1000,"Get 1000 replies (5 trees)"},
    {"Canopy",0,GL_CANOPY,90,90,96,M_CHATS,2000,"Get 2000 replies (10 trees)"},
    /* Chats */
    {"Chatterbox",1,GL_BUBBLE,52,120,246,M_CHATS,10,"Get 10 replies"},
    {"Storyteller",1,GL_BOOK,52,120,246,M_CHATS,50,"Get 50 replies"},
    {"Legend",1,GL_LAUREL,255,200,60,M_CHATS,500,"Get 500 replies"},
    /* Streaks: consecutive days with a reply */
    {"Droplet",2,GL_DROP,52,120,246,M_STREAK,2,"Chat 2 days in a row"},
    {"Warrior",2,GL_FLAME,255,130,40,M_STREAK,7,"Chat 7 days in a row"},
    {"Stream",2,GL_DROPS,52,120,246,M_STREAK,14,"Chat 14 days in a row"},
    {"Mentor",2,GL_TROPHY,255,190,50,M_STREAK,30,"Chat 30 days in a row"},
    {"River",2,GL_WAVE,52,120,246,M_STREAK,60,"Chat 60 days in a row"},
    {"Centurion",2,GL_MEDAL,255,190,50,M_STREAK,100,"Chat 100 days in a row"},
    {"Evergreen",2,GL_PINE,52,170,90,M_STREAK,365,"Chat 365 days in a row"},
    /* Friends: needs EcoGPT's API */
    {"Teammate",3,GL_TWO,52,120,246,M_API,0,"Needs EcoGPT's API"},
    {"Ambassador",3,GL_RING,52,199,89,M_API,0,"Needs EcoGPT's API"},
    {"Influencer",3,GL_HAND,52,199,89,M_API,0,"Needs EcoGPT's API"},
    {"Squad",3,GL_THREE,52,120,246,M_API,0,"Needs EcoGPT's API"},
    {"Champion",3,GL_PODIUM,255,190,50,M_API,0,"Needs EcoGPT's API"},
    /* Discover: things you do in this app */
    {"Makeover",4,GL_GLOBE,52,120,246,M_FLAG,FL_NAME,"Rename your companion"},
    {"Spark",4,GL_BOLT,255,190,50,M_FLAG,FL_VOICE,"Try voice chat"},
    {"Visionary",4,GL_BULB,255,190,50,M_FLAG,FL_CAMERA,"Take a photo with the camera"},
    {"Builder",4,GL_FOLDER,52,120,246,M_FLAG,FL_FILE,"Attach a file from the SD card"},
    {"Autopilot",4,GL_CLOCK,175,82,222,M_FLAG,FL_INSTR,"Write custom instructions"},
    {"Powerhouse",4,GL_BATTERY,52,199,89,M_FLAG,FL_PRIV,"Use a private chat"}
};

/* Palette taken from the iOS screenshots: black UI, dark gray cards, selectable accent. */
static u32 cBg, cCard, cCard2, cWhite, cMuted, cTrack, cBar, cAccent;
static u32 cSkyTop, cSkyBot, cGold1, cGold2, cSideL, cSideR, cTrunk, cOrange, cRed, cPine, cCloud, cGoldTxt;

static Msg msgs[MAX_MSGS];
static int nmsg = 0;
static DLine lines[MAXL];
static int nl = 0, scrollOff = 0, chats = 0, accent = 0, tsize = 1;
static int flags = 0, streak = 0, lastDay = 0;
static int wrapN = 50, lineH = 15, rowsN = 11;
static bool dirty = true, privateMode = false, running = false;
static Page page = P_CHAT, backPage = P_MENU;
static Config cfg;
static C2D_TextBuf tbuf;
static Job job;
static Thread th = NULL;
static int frameNo = 0;

static int focus = F_INPUT;
static bool showFocus = false;
static FRect fr[MAX_FR];
static int nfr = 0;

static int profTab = 0, lbGlobal = 0;
static int setSel = 1;
static float setScroll = 0, setY[NSET], setH = 0;
static float gScroll = 0;                /* scroll for tools / badges / files */
static float badgeY[NBADGE], hdrY[5], badgesH = 0;
static int badgeCol[NBADGE];
static int testState = 0;                /* 0 idle, 1 running, 2 ok, 3 failed */
static int resetArm = 0;
static char toastMsg[128];
static int toastT = 0;

/* voice / camera / attachments */
static bool listening = false;
static char voiceNote[96] = "";
static bool haveShot = false;
static int shotNo = 0;
static char attPath[256] = "", attName[64] = "";
static int attKind = 0;                  /* 0 none, 1 photo, 2 file */
static char fileNames[NFILES][64];
static int nfiles = 0, fileMode = 0;     /* fileMode: 0 photos, 1 PDFs, 2 all files */

/* ---------- text + shapes ---------- */
static float textZ = 0.95f;
static void txt(const char *s, float x, float y, float sc, u32 col)
{
    C2D_Text t;
    C2D_TextParse(&t, tbuf, s);
    C2D_TextOptimize(&t);
    C2D_DrawText(&t, C2D_WithColor, x, y, textZ, sc, sc, col);
}
static float txtw(const char *s, float sc)
{
    C2D_Text t; float w, h;
    C2D_TextParse(&t, tbuf, s);
    C2D_TextGetDimensions(&t, sc, sc, &w, &h);
    return w;
}
static void txtc(const char *s, float cx, float y, float sc, u32 col) { txt(s, cx - txtw(s, sc) / 2, y, sc, col); }
static void txtr(const char *s, float rx, float y, float sc, u32 col) { txt(s, rx - txtw(s, sc), y, sc, col); }

static void qfan(float cx, float cy, float r, float a0, u32 c, float z)
{
    const int seg = 8;
    for (int k = 0; k < seg; k++) {
        float t0 = a0 + k * (PI_F / 2) / seg, t1 = a0 + (k + 1) * (PI_F / 2) / seg;
        C2D_DrawTriangle(cx, cy, c, cx + cosf(t0) * r, cy + sinf(t0) * r, c,
                         cx + cosf(t1) * r, cy + sinf(t1) * r, c, z);
    }
}
static void rrect(float x, float y, float w, float h, float r, u32 c, float z)
{
    if (r > h / 2) r = h / 2;
    if (r > w / 2) r = w / 2;
    C2D_DrawRectSolid(x + r, y, z, w - 2 * r, h, c);
    C2D_DrawRectSolid(x, y + r, z, r, h - 2 * r, c);
    C2D_DrawRectSolid(x + w - r, y + r, z, r, h - 2 * r, c);
    qfan(x + r,     y + r,     r, PI_F,        c, z);
    qfan(x + w - r, y + r,     r, 1.5f * PI_F, c, z);
    qfan(x + w - r, y + h - r, r, 0.0f,        c, z);
    qfan(x + r,     y + h - r, r, 0.5f * PI_F, c, z);
}
static void quad(float x0, float y0, float x1, float y1, float x2, float y2, float x3, float y3, u32 c, float z)
{
    C2D_DrawTriangle(x0, y0, c, x1, y1, c, x2, y2, c, z);
    C2D_DrawTriangle(x0, y0, c, x2, y2, c, x3, y3, c, z);
}
static bool hit(const touchPosition *t, int x, int y, int w, int h)
{
    return t->px >= x && t->px < x + w && t->py >= y && t->py < y + h;
}

static void routline(float x, float y, float w, float h, float r, float t, u32 c, float z)
{
    if (r > h / 2) r = h / 2;
    if (r > w / 2) r = w / 2;
    float x2 = x + w, y2 = y + h;
    C2D_DrawLine(x + r, y, c, x2 - r, y, c, t, z);
    C2D_DrawLine(x + r, y2, c, x2 - r, y2, c, t, z);
    C2D_DrawLine(x, y + r, c, x, y2 - r, c, t, z);
    C2D_DrawLine(x2, y + r, c, x2, y2 - r, c, t, z);
    float cx[4] = { x2 - r, x2 - r, x + r, x + r };
    float cy[4] = { y + r, y2 - r, y2 - r, y + r };
    for (int q = 0; q < 4; q++) {
        float a0 = q * 1.5708f - 1.5708f;
        for (int s = 0; s < 5; s++) {
            float a = a0 + s * 0.31416f, b = a0 + (s + 1) * 0.31416f;
            C2D_DrawLine(cx[q] + cosf(a) * r, cy[q] + sinf(a) * r, c,
                         cx[q] + cosf(b) * r, cy[q] + sinf(b) * r, c, t, z);
        }
    }
}
static bool isF(int id) { return showFocus && focus == id; }
static void fring(int id, float x, float y, float w, float h, float r)
{
    if (isF(id)) routline(x - 2.5f, y - 2.5f, w + 5, h + 5, r + 2.5f, 2.0f, cWhite, 0.6f);
}

static void hexagon(float cx, float cy, float r, u32 c, float z)
{
    for (int k = 0; k < 6; k++) {
        float a0 = (-90 + 60 * k) * 0.0174533f, a1 = (-90 + 60 * (k + 1)) * 0.0174533f;
        C2D_DrawTriangle(cx, cy, c, cx + cosf(a0) * r, cy + sinf(a0) * r, c,
                         cx + cosf(a1) * r, cy + sinf(a1) * r, c, z);
    }
}
static void hexDashed(float cx, float cy, float r, u32 c, float z)
{
    for (int k = 0; k < 6; k++) {
        float a0 = (-90 + 60 * k) * 0.0174533f, a1 = (-90 + 60 * (k + 1)) * 0.0174533f;
        float x0 = cx + cosf(a0) * r, y0 = cy + sinf(a0) * r, x1 = cx + cosf(a1) * r, y1 = cy + sinf(a1) * r;
        for (int s = 0; s < 3; s++) {
            float t0 = s / 3.0f + 0.04f, t1 = (s + 1) / 3.0f - 0.06f;
            C2D_DrawLine(x0 + (x1 - x0) * t0, y0 + (y1 - y0) * t0, c,
                         x0 + (x1 - x0) * t1, y0 + (y1 - y0) * t1, c, 1.4f, z);
        }
    }
}
static void person(float cx, float cy, float s, u32 c, float z)
{
    C2D_DrawCircleSolid(cx, cy - s * 0.35f, z, s * 0.32f, c);
    rrect(cx - s * 0.55f, cy + s * 0.05f, s * 1.1f, s * 0.6f, s * 0.3f, c, z);
}
static void miniTree(float x, float y, float s)
{
    C2D_DrawRectSolid(x - s * 0.12f, y + s * 0.2f, 0.4f, s * 0.24f, s * 0.5f, cTrunk);
    C2D_DrawCircleSolid(x, y, 0.41f, s * 0.5f, cBar);
    C2D_DrawCircleSolid(x - s * 0.38f, y + s * 0.18f, 0.42f, s * 0.32f, cBar);
    C2D_DrawCircleSolid(x + s * 0.38f, y + s * 0.18f, 0.42f, s * 0.32f, cBar);
}

/* The blue hooded companion from the iOS app. */
static void mascot(float x, float y, float r)
{
    u32 navy = CLR(28, 34, 96);
    C2D_DrawCircleSolid(x, y, 0.3f, r, CLR(48, 98, 214));
    C2D_DrawCircleSolid(x, y - r * 0.03f, 0.31f, r * 0.93f, CLR(84, 142, 250));
    C2D_DrawCircleSolid(x - r * 0.28f, y - r * 0.52f, 0.32f, r * 0.42f, GLA(170, 210, 255, 170));
    rrect(x - r * 0.66f, y - r * 0.22f, r * 1.32f, r * 0.95f, r * 0.48f, CLR(250, 251, 255), 0.4f);
    rrect(x - r * 0.42f, y + r * 0.02f, r * 0.2f, r * 0.34f, r * 0.1f, navy, 0.5f);
    rrect(x + r * 0.22f, y + r * 0.02f, r * 0.2f, r * 0.34f, r * 0.1f, navy, 0.5f);
    C2D_DrawCircleSolid(x - r * 0.36f, y + r * 0.1f, 0.55f, r * 0.05f, CLR(255, 255, 255));
    C2D_DrawCircleSolid(x + r * 0.28f, y + r * 0.1f, 0.55f, r * 0.05f, CLR(255, 255, 255));
    C2D_DrawLine(x - r * 0.14f, y + r * 0.42f, navy, x, y + r * 0.5f, navy, r * 0.06f, 0.55f);
    C2D_DrawLine(x, y + r * 0.5f, navy, x + r * 0.14f, y + r * 0.42f, navy, r * 0.06f, 0.55f);
}

/* Liquid-glass card: translucent body, top sheen and a bright rim. */
static void glassCard(float x, float y, float w, float h, float r, float z)
{
    rrect(x, y, w, h, r, GLA(190, 205, 240, 40), z);
    rrect(x + 1, y + 1, w - 2, h * 0.5f, r, GLA(255, 255, 255, 26), z + 0.01f);
    routline(x + 0.5f, y + 0.5f, w - 1, h - 1, r, 1.0f, GLA(255, 255, 255, 80), z + 0.02f);
}

static void bgGlow(void)
{
    static const float ox[3] = { 40, 290, 170 }, oy[3] = { 36, 210, 130 }, orr[3] = { 95, 115, 70 };
    for (int k = 0; k < 3; k++)
        for (int j = 3; j >= 1; j--)
            C2D_DrawCircleSolid(ox[k], oy[k], 0.05f, orr[k] * j / 3.0f,
                                GLA(ACC[accent][0], ACC[accent][1], ACC[accent][2], 9 + (3 - j) * 4));
}

static void toast(const char *s) { snprintf(toastMsg, sizeof toastMsg, "%s", s); toastT = 150; }

/* ---------- badge glyphs (drawn with shapes, no emoji) ---------- */
static float GZ = 0.32f;
#define NZ (GZ += 0.003f)

static void drop(float x, float y, float s, u32 c)
{
    C2D_DrawTriangle(x - s * 0.55f, y + s * 0.1f, c, x + s * 0.55f, y + s * 0.1f, c, x, y - s * 0.95f, c, NZ);
    C2D_DrawCircleSolid(x, y + s * 0.2f, NZ, s * 0.55f, c);
}
static void trunkAt(float x, float y, float s, u32 T)
{
    C2D_DrawRectSolid(x - s * 0.12f, y + s * 0.2f, NZ, s * 0.24f, s * 0.8f, T);
}
static void glyph(int g, float x, float y, float s, u32 P, u32 W, u32 H, u32 T)
{
    switch (g) {
    case GL_LEAF:
        C2D_DrawCircleSolid(x + s * 0.12f, y - s * 0.1f, NZ, s * 0.62f, P);
        C2D_DrawLine(x - s * 0.55f, y + s * 0.6f, H, x + s * 0.45f, y - s * 0.45f, H, s * 0.1f, NZ);
        break;
    case GL_SEED:
        C2D_DrawCircleSolid(x, y + s * 0.2f, NZ, s * 0.55f, T);
        C2D_DrawTriangle(x, y - s * 0.3f, P, x + s * 0.5f, y - s * 0.8f, P, x + s * 0.2f, y - s * 0.2f, P, NZ);
        break;
    case GL_TREE1:
        trunkAt(x, y, s, T);
        C2D_DrawCircleSolid(x, y - s * 0.2f, NZ, s * 0.6f, P);
        break;
    case GL_TREE2:
        trunkAt(x, y, s, T);
        C2D_DrawCircleSolid(x - s * 0.45f, y - s * 0.1f, NZ, s * 0.42f, P);
        C2D_DrawCircleSolid(x + s * 0.45f, y - s * 0.1f, NZ, s * 0.42f, P);
        break;
    case GL_TREE3:
        trunkAt(x, y, s, T);
        C2D_DrawCircleSolid(x - s * 0.5f, y, NZ, s * 0.4f, P);
        C2D_DrawCircleSolid(x + s * 0.5f, y, NZ, s * 0.4f, P);
        C2D_DrawCircleSolid(x, y - s * 0.4f, NZ, s * 0.4f, P);
        break;
    case GL_BUSH:
        C2D_DrawCircleSolid(x - s * 0.5f, y + s * 0.1f, NZ, s * 0.4f, P);
        C2D_DrawCircleSolid(x + s * 0.5f, y + s * 0.1f, NZ, s * 0.4f, P);
        C2D_DrawCircleSolid(x, y - s * 0.2f, NZ, s * 0.5f, P);
        C2D_DrawCircleSolid(x - s * 0.2f, y + s * 0.4f, NZ, s * 0.12f, W);
        C2D_DrawCircleSolid(x + s * 0.3f, y + s * 0.2f, NZ, s * 0.12f, W);
        break;
    case GL_SPROUT:
        C2D_DrawCircleSolid(x, y + s * 0.9f, NZ, s * 0.75f, T);
        C2D_DrawCircleSolid(x - s * 0.4f, y - s * 0.2f, NZ, s * 0.4f, P);
        C2D_DrawCircleSolid(x + s * 0.4f, y - s * 0.2f, NZ, s * 0.4f, P);
        break;
    case GL_ACORN:
        C2D_DrawCircleSolid(x, y + s * 0.25f, NZ, s * 0.55f, T);
        C2D_DrawCircleSolid(x, y - s * 0.35f, NZ, s * 0.45f, P);
        break;
    case GL_ORCHARD:
        glyph(GL_TREE2, x, y, s, P, W, H, T);
        C2D_DrawCircleSolid(x - s * 0.5f, y - s * 0.1f, NZ, s * 0.12f, W);
        C2D_DrawCircleSolid(x + s * 0.5f, y - s * 0.3f, NZ, s * 0.12f, W);
        break;
    case GL_GLOBE:
        C2D_DrawCircleSolid(x, y, NZ, s * 0.9f, P);
        C2D_DrawCircleSolid(x - s * 0.3f, y - s * 0.2f, NZ, s * 0.35f, W);
        C2D_DrawCircleSolid(x + s * 0.3f, y + s * 0.3f, NZ, s * 0.3f, W);
        break;
    case GL_CANOPY:
        trunkAt(x, y, s, T);
        C2D_DrawCircleSolid(x - s * 0.4f, y - s * 0.3f, NZ, s * 0.45f, P);
        C2D_DrawCircleSolid(x + s * 0.4f, y - s * 0.3f, NZ, s * 0.45f, P);
        C2D_DrawCircleSolid(x, y - s * 0.5f, NZ, s * 0.5f, P);
        break;
    case GL_BUBBLE:
        C2D_DrawCircleSolid(x, y - s * 0.1f, NZ, s * 0.8f, P);
        C2D_DrawTriangle(x - s * 0.3f, y + s * 0.5f, P, x - s * 0.7f, y + s * 0.95f, P, x + s * 0.1f, y + s * 0.6f, P, NZ);
        C2D_DrawCircleSolid(x - s * 0.35f, y - s * 0.1f, NZ, s * 0.14f, W);
        C2D_DrawCircleSolid(x, y - s * 0.1f, NZ, s * 0.14f, W);
        C2D_DrawCircleSolid(x + s * 0.35f, y - s * 0.1f, NZ, s * 0.14f, W);
        break;
    case GL_BOOK:
        C2D_DrawRectSolid(x - s * 0.9f, y - s * 0.5f, NZ, s * 0.85f, s * 1.0f, W);
        C2D_DrawRectSolid(x + s * 0.05f, y - s * 0.5f, NZ, s * 0.85f, s * 1.0f, W);
        C2D_DrawRectSolid(x - s * 0.05f, y - s * 0.5f, NZ, s * 0.1f, s * 1.0f, P);
        break;
    case GL_LAUREL:
        C2D_DrawCircleSolid(x, y, NZ, s * 0.95f, P);
        C2D_DrawCircleSolid(x, y, NZ, s * 0.6f, H);
        break;
    case GL_DROP:
        drop(x, y, s, P);
        break;
    case GL_FLAME:
        C2D_DrawCircleSolid(x, y + s * 0.3f, NZ, s * 0.7f, P);
        C2D_DrawTriangle(x - s * 0.7f, y + s * 0.3f, P, x + s * 0.7f, y + s * 0.3f, P, x, y - s * 0.9f, P, NZ);
        C2D_DrawTriangle(x - s * 0.35f, y + s * 0.4f, W, x + s * 0.35f, y + s * 0.4f, W, x, y - s * 0.3f, W, NZ);
        break;
    case GL_DROPS:
        drop(x - s * 0.45f, y + s * 0.2f, s * 0.7f, P);
        drop(x + s * 0.4f, y + s * 0.1f, s * 0.9f, P);
        break;
    case GL_TROPHY:
        C2D_DrawCircleSolid(x, y - s * 0.3f, NZ, s * 0.6f, P);
        C2D_DrawRectSolid(x - s * 0.15f, y + s * 0.2f, NZ, s * 0.3f, s * 0.5f, P);
        C2D_DrawRectSolid(x - s * 0.5f, y + s * 0.7f, NZ, s * 1.0f, s * 0.25f, T);
        break;
    case GL_WAVE:
        C2D_DrawCircleSolid(x - s * 0.5f, y + s * 0.2f, NZ, s * 0.4f, P);
        C2D_DrawCircleSolid(x + s * 0.3f, y - s * 0.1f, NZ, s * 0.4f, P);
        C2D_DrawCircleSolid(x + s * 0.2f, y + s * 0.5f, NZ, s * 0.3f, P);
        break;
    case GL_MEDAL:
        C2D_DrawTriangle(x - s * 0.6f, y + s * 0.5f, T, x - s * 0.15f, y + s * 0.5f, T, x - s * 0.3f, y + s * 1.0f, T, NZ);
        C2D_DrawTriangle(x + s * 0.6f, y + s * 0.5f, T, x + s * 0.15f, y + s * 0.5f, T, x + s * 0.3f, y + s * 1.0f, T, NZ);
        C2D_DrawCircleSolid(x, y - s * 0.1f, NZ, s * 0.7f, P);
        C2D_DrawCircleSolid(x, y - s * 0.1f, NZ, s * 0.4f, W);
        break;
    case GL_PINE:
        C2D_DrawTriangle(x, y - s * 0.9f, P, x - s * 0.7f, y, P, x + s * 0.7f, y, P, NZ);
        C2D_DrawTriangle(x, y - s * 0.4f, P, x - s * 0.85f, y + s * 0.5f, P, x + s * 0.85f, y + s * 0.5f, P, NZ);
        C2D_DrawRectSolid(x - s * 0.12f, y + s * 0.5f, NZ, s * 0.24f, s * 0.4f, T);
        break;
    case GL_TWO:
        person(x - s * 0.4f, y, s * 0.9f, P, NZ);
        person(x + s * 0.4f, y, s * 0.9f, W, NZ);
        break;
    case GL_THREE:
        person(x - s * 0.6f, y + s * 0.2f, s * 0.7f, H, NZ);
        person(x + s * 0.6f, y + s * 0.2f, s * 0.7f, H, NZ);
        person(x, y, s * 0.9f, P, NZ);
        break;
    case GL_RING:
        C2D_DrawCircleSolid(x, y, NZ, s * 0.85f, P);
        C2D_DrawCircleSolid(x, y, NZ, s * 0.5f, H);
        break;
    case GL_HAND:
        C2D_DrawRectSolid(x - s * 0.8f, y + s * 0.4f, NZ, s * 1.6f, s * 0.5f, P);
        C2D_DrawRectSolid(x - s * 0.05f, y - s * 0.1f, NZ, s * 0.1f, s * 0.5f, T);
        C2D_DrawCircleSolid(x - s * 0.2f, y - s * 0.2f, NZ, s * 0.35f, P);
        C2D_DrawCircleSolid(x + s * 0.2f, y - s * 0.2f, NZ, s * 0.35f, P);
        break;
    case GL_PODIUM:
        C2D_DrawRectSolid(x - s * 0.95f, y + s * 0.2f, NZ, s * 0.55f, s * 0.7f, W);
        C2D_DrawRectSolid(x - s * 0.2f, y - s * 0.3f, NZ, s * 0.6f, s * 1.2f, P);
        C2D_DrawRectSolid(x + s * 0.4f, y + s * 0.4f, NZ, s * 0.55f, s * 0.5f, H);
        break;
    case GL_BOLT:
        C2D_DrawTriangle(x + s * 0.2f, y - s * 0.9f, P, x - s * 0.6f, y + s * 0.2f, P, x + s * 0.1f, y + s * 0.1f, P, NZ);
        C2D_DrawTriangle(x - s * 0.1f, y - s * 0.1f, P, x + s * 0.6f, y - s * 0.1f, P, x - s * 0.2f, y + s * 0.9f, P, NZ);
        break;
    case GL_BULB:
        C2D_DrawCircleSolid(x, y - s * 0.2f, NZ, s * 0.7f, P);
        C2D_DrawRectSolid(x - s * 0.35f, y + s * 0.5f, NZ, s * 0.7f, s * 0.35f, W);
        C2D_DrawRectSolid(x - s * 0.2f, y + s * 0.85f, NZ, s * 0.4f, s * 0.15f, W);
        break;
    case GL_FOLDER:
        C2D_DrawRectSolid(x - s * 0.9f, y - s * 0.5f, NZ, s * 0.8f, s * 0.35f, P);
        C2D_DrawRectSolid(x - s * 0.9f, y - s * 0.2f, NZ, s * 1.8f, s * 1.2f, P);
        C2D_DrawRectSolid(x - s * 0.6f, y - s * 0.6f, NZ, s * 1.1f, s * 0.6f, W);
        break;
    case GL_CLOCK:
        C2D_DrawCircleSolid(x, y, NZ, s * 0.95f, P);
        C2D_DrawCircleSolid(x, y, NZ, s * 0.75f, H);
        C2D_DrawLine(x, y, W, x, y - s * 0.55f, W, s * 0.12f, NZ);
        C2D_DrawLine(x, y, W, x + s * 0.4f, y, W, s * 0.12f, NZ);
        break;
    case GL_BATTERY:
        rrect(x - s * 0.95f, y - s * 0.45f, s * 1.7f, s * 0.9f, s * 0.2f, P, NZ);
        C2D_DrawRectSolid(x + s * 0.75f, y - s * 0.2f, NZ, s * 0.2f, s * 0.4f, P);
        break;
    }
}

/* One badge disc. got = unlocked. Locked badges are drawn in grey. */
static void drawBadgeIcon(int i, float cx, float cy, float r, bool got)
{
    const Badge *b = &BADGES[i];
    GZ = 0.32f;
    C2D_DrawCircleSolid(cx, cy, 0.3f, r, got ? CLR(70, 70, 76) : CLR(44, 44, 48));
    C2D_DrawCircleSolid(cx, cy, 0.305f, r - 1.5f, got ? cCard2 : CLR(34, 34, 36));
    u32 P = got ? CLR(b->r, b->g, b->b) : CLR(92, 92, 98);
    u32 W = got ? cWhite : CLR(120, 120, 126);
    u32 H = got ? cCard2 : CLR(30, 30, 32);
    u32 T = got ? CLR(120, 82, 46) : CLR(84, 84, 90);
    glyph(b->glyph, cx, cy, r * 0.62f, P, W, H, T);
}

/* ---------- stats / settings persistence ---------- */
static void setTextSize(void)
{
    wrapN = TWRAP[tsize]; lineH = TLH[tsize];
    rowsN = (CH_BOT - CH_TOP) / lineH;
    dirty = true;
}
static void loadStats(void)
{
    FILE *f = fopen(STATS_FILE, "r");
    if (!f) return;
    int a = 0, c = 0, t = 1, fl = 0, st = 0, ld = 0;
    int n = fscanf(f, "chats=%d accent=%d tsize=%d flags=%d streak=%d lastday=%d", &c, &a, &t, &fl, &st, &ld);
    if (n >= 1) chats = c;
    if (n >= 2 && a >= 0 && a < 5) accent = a;
    if (n >= 3 && t >= 0 && t < 3) tsize = t;
    if (n >= 4) flags = fl;
    if (n >= 5) streak = st;
    if (n >= 6) lastDay = ld;
    fclose(f);
}
static void saveStats(void)
{
    FILE *f = fopen(STATS_FILE, "w");
    if (f) {
        fprintf(f, "chats=%d accent=%d tsize=%d flags=%d streak=%d lastday=%d\n",
                chats, accent, tsize, flags, streak, lastDay);
        fclose(f);
    }
}
static void setAccent(void) { cAccent = CLR(ACC[accent][0], ACC[accent][1], ACC[accent][2]); }
static void saveCfg(void) { if (cfg_save(&cfg) != 0) toast("Couldn't save to the SD card."); }

static void ensureDirs(void)
{
    mkdir("sdmc:/3ds", 0777);
    mkdir("sdmc:/3ds/ecogpt", 0777);
    mkdir(UPLOAD_DIR, 0777);
}

/* Counts a reply for the day streak (not for private chats). */
static void touchStreak(void)
{
    int today = (int)(time(NULL) / 86400);
    if (today == lastDay) return;
    streak = (today == lastDay + 1) ? streak + 1 : 1;
    lastDay = today;
}

static bool badgeMet(int i)
{
    const Badge *b = &BADGES[i];
    switch (b->metric) {
    case M_CHATS:  return chats >= b->need;
    case M_STREAK: return streak >= b->need;
    case M_FLAG:   return (flags & b->need) != 0;
    default:       return false;
    }
}
static int countBadges(void)
{
    int n = 0;
    for (int i = 0; i < NBADGE; i++) n += badgeMet(i) ? 1 : 0;
    return n;
}
static void layoutBadges(void)
{
    float y = 44;
    for (int c = 0; c < 5; c++) {
        hdrY[c] = y;
        y += 24;
        int k = 0;
        for (int i = 0; i < NBADGE; i++) {
            if (BADGES[i].cat != c) continue;
            badgeY[i] = y + (k / 3) * 74;
            badgeCol[i] = k % 3;
            k++;
        }
        y += ((k + 2) / 3) * 74 + 8;
    }
    badgesH = y + 10;
}

/* ---------- chat model ---------- */
static void addMsg(int role, const char *text)
{
    if (nmsg == MAX_MSGS) { memmove(msgs, msgs + 2, (MAX_MSGS - 2) * sizeof(Msg)); nmsg -= 2; }
    msgs[nmsg].role = role;
    snprintf(msgs[nmsg].text, MSG_LEN, "%s", text);
    nmsg++;
    dirty = true;
    scrollOff = 0;
}

static void rebuild(void)
{
    nl = 0;
    for (int m = 0; m < nmsg; m++) {
        const char *p = msgs[m].text;
        int first = nl, maxc = 0;
        while (*p && nl < MAXL - 1) {
            int i = 0, lastsp = -1;
            while (p[i] && p[i] != '\n' && i < wrapN) { if (p[i] == ' ') lastsp = i; i++; }
            if (i == wrapN && p[i] && p[i] != '\n' && p[i] != ' ' && lastsp > 0) i = lastsp;
            memcpy(lines[nl].text, p, i);
            lines[nl].text[i] = 0;
            lines[nl].role = msgs[m].role;
            if (i > maxc) maxc = i;
            nl++;
            p += i;
            if (*p == '\n') p++;
            while (*p == ' ') p++;
        }
        for (int k = first; k < nl; k++) lines[k].w = (int)(maxc * TCW[tsize]) + 16;
        if (nl < MAXL) { lines[nl].text[0] = 0; lines[nl].role = -1; lines[nl].w = 0; nl++; }
    }
    dirty = false;
}

/* ---------- top screen ---------- */
static void treeAt(float x, float y, int kind, float s)
{
    C2D_DrawRectSolid(x - 2 * s, y - 14 * s, 0.45f, 4 * s, 14 * s, cTrunk);
    if (kind == 2) {
        C2D_DrawTriangle(x - 9 * s, y - 12 * s, cPine, x + 9 * s, y - 12 * s, cPine, x, y - 32 * s, cPine, 0.46f);
        C2D_DrawTriangle(x - 7 * s, y - 22 * s, cPine, x + 7 * s, y - 22 * s, cPine, x, y - 40 * s, cPine, 0.47f);
    } else {
        u32 c = kind ? cRed : cOrange;
        C2D_DrawCircleSolid(x, y - 22 * s, 0.46f, 10 * s, c);
        C2D_DrawCircleSolid(x - 4 * s, y - 25 * s, 0.47f, 5 * s, CLR(255, 190, 120));
    }
}

static void drawProfileTop(void)
{
    C2D_DrawRectangle(0, 0, 0.1f, TOP_W, 175, cSkyTop, cSkyTop, cSkyBot, cSkyBot);
    C2D_DrawCircleSolid(52, 62, 0.12f, 11, cCloud);  C2D_DrawCircleSolid(70, 56, 0.12f, 15, cCloud);
    C2D_DrawCircleSolid(88, 64, 0.12f, 10, cCloud);  C2D_DrawCircleSolid(334, 92, 0.12f, 13, cCloud);
    C2D_DrawCircleSolid(354, 86, 0.12f, 17, cCloud); C2D_DrawCircleSolid(374, 94, 0.12f, 10, cCloud);

    const float ox = 200, oy = 12, ax = 28, ay = 14, th_ = 18;
    quad(ox - 4 * ax, oy + 4 * ay, ox, oy + 8 * ay, ox, oy + 8 * ay + th_, ox - 4 * ax, oy + 4 * ay + th_, cSideL, 0.2f);
    quad(ox, oy + 8 * ay, ox + 4 * ax, oy + 4 * ay, ox + 4 * ax, oy + 4 * ay + th_, ox, oy + 8 * ay + th_, cSideR, 0.2f);
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 4; j++) {
            float px = ox + (i - j) * ax, py = oy + (i + j) * ay;
            quad(px, py, px + ax, py + ay, px, py + 2 * ay, px - ax, py + ay, ((i + j) & 1) ? cGold2 : cGold1, 0.3f);
        }
    static const int order[16] = {5, 10, 3, 12, 0, 15, 6, 9, 1, 14, 2, 13, 4, 11, 7, 8};
    bool occ[16] = {0};
    int trees = chats / CHATS_PER_TREE;
    int shown = trees > 16 ? 16 : trees;
    for (int k = 0; k < shown; k++) occ[order[k]] = true;
    for (int s = 0; s <= 6; s++)
        for (int i = 0; i < 4; i++) {
            int j = s - i;
            if (j < 0 || j > 3 || !occ[j * 4 + i]) continue;
            treeAt(ox + (i - j) * ax, oy + (i + j + 1) * ay, (i * 3 + j) % 3, 0.8f);
        }

    static const float bx[8] = { 0, 50, 112, 160, 240, 288, 350, 400 };
    static const float br[8] = { 40, 30, 18, 9, 9, 18, 30, 40 };
    for (int i = 0; i < 8; i++) C2D_DrawCircleSolid(bx[i], 176, 0.5f, br[i], cBg);
    C2D_DrawRectSolid(0, 170, 0.5f, TOP_W, 70, cBg);
    C2D_DrawCircleSolid(192, 160, 0.6f, 2.5f, cTrack);
    C2D_DrawCircleSolid(208, 160, 0.6f, 2.5f, cWhite);

    C2D_DrawCircleSolid(176, 190, 0.6f, 19, cCard2);
    person(176, 192, 22, cMuted, 0.65f);
    C2D_DrawCircleSolid(214, 189, 0.62f, 23, cWhite);
    mascot(214, 189, 21);
    C2D_DrawCircleSolid(230, 204, 0.7f, 8, cCard2);
    C2D_DrawLine(226, 208, cWhite, 233, 201, cWhite, 1.6f, 0.75f);

    char b[48];
    snprintf(b, sizeof b, "& %s", cfg.name);
    txtc(b, 200, 214, 0.7f, cWhite);
}

static void drawTop(int frame)
{
    (void)frame;
    if (page == P_PROFILE) { drawProfileTop(); return; }

    if (page == P_CHAT && isF(F_MASCOT)) routline(MX - MR - 3, MY - MR - 3, 2 * MR + 6, 2 * MR + 6, MR + 3, 2.0f, cWhite, 0.6f);
    mascot(MX, MY, MR);

    if (nmsg == 0) return;

    if (dirty) rebuild();
    int maxScroll = nl > rowsN ? nl - rowsN : 0;
    if (scrollOff > maxScroll) scrollOff = maxScroll;
    if (scrollOff < 0) scrollOff = 0;
    int end = nl - scrollOff;
    int start = end - rowsN; if (start < 0) start = 0;
    for (int i = start; i < end; i++) {
        const DLine *d = &lines[i];
        if (d->role < 0) continue;
        float y = CH_TOP + (i - start) * lineH;
        if (d->role == 0) {
            float x = TOP_W - 10 - d->w;
            C2D_DrawRectSolid(x, y, 0.2f, d->w, lineH, cCard2);
            txt(d->text, x + 8, y - 1, TSC[tsize], cWhite);
        } else {
            txt(d->text, 14, y - 1, TSC[tsize], cWhite);
        }
    }
    if (scrollOff > 0)
        C2D_DrawTriangle(386, 226, cMuted, 394, 226, cMuted, 390, 232, cMuted, 0.6f);
    if (scrollOff < maxScroll)
        C2D_DrawTriangle(386, 52, cMuted, 394, 52, cMuted, 390, 46, cMuted, 0.6f);
}

/* ---------- focus rectangles ---------- */
static bool scrollPage(void) { return page == P_TOOLS || page == P_BADGES || page == P_FILES; }

static void addR(int id, float x, float y, float w, float h)
{
    if (nfr < MAX_FR) { fr[nfr].id = id; fr[nfr].x = x; fr[nfr].y = y; fr[nfr].w = w; fr[nfr].h = h; nfr++; }
}

static float contentH(void)
{
    switch (page) {
    case P_TOOLS:  return 44 + ((NTOOLS + 3) / 4) * 58 + 10;
    case P_BADGES: return badgesH;
    case P_FILES:  return 44 + nfiles * 28 + 10;
    default:       return 0;
    }
}
static void clampG(void)
{
    float mx = contentH() - BODY_B;
    if (mx < 0) mx = 0;
    if (gScroll > mx) gScroll = mx;
    if (gScroll < 0) gScroll = 0;
}

static void buildRects(void)
{
    nfr = 0;
    switch (page) {
    case P_CHAT:
        addR(F_MASCOT, MX - MR - 40, -240 + MY - MR, 2 * MR, 2 * MR);
        addR(F_MENU, 10, 10, 36, 36);
        addR(F_PRIV, 274, 10, 36, 36);
        if (nmsg == 0) {
            if (!cfg_ready(&cfg)) addR(F_SETUP, 80, 122, 160, 28);
            else for (int i = 0; i < 3; i++) addR(F_SUG0 + i, 16, 62 + i * 34, 288, 30);
        }
        if (attKind) addR(F_CHIP, 8, 168, 304, 20);
        addR(F_ATTACH, 8, 192, 36, 40);
        addR(F_INPUT, 48, 192, 196, 40);
        addR(F_MIC, 248, 192, 32, 40);
        break;
    case P_MENU:
        addR(F_M_TOOLS, 16, 64, 288, 36);
        addR(F_M_IMPACT, 16, 108, 288, 36);
        addR(F_M_SETTINGS, 16, 152, 288, 36);
        addR(F_M_CHAT, 14, 194, 110, 36);
        addR(F_M_VOICE, 130, 194, 110, 36);
        addR(F_M_GEAR, 254, 194, 52, 36);
        break;
    case P_PROFILE:
        addR(F_P_CLOSE, 11, 7, 34, 34);
        addR(F_P_TAB0, 54, 10, 124, 28);
        addR(F_P_TAB1, 184, 10, 124, 28);
        if (profTab == 0) addR(F_P_BADGES, 16, 164, 288, 68);
        if (profTab == 1) { addR(F_P_DROP, 20, 52, 104, 26); addR(F_P_ADD, 176, 52, 128, 26); }
        break;
    case P_TOOLS:
        addR(F_P_CLOSE, 11, 7, 34, 34);
        for (int i = 0; i < NTOOLS; i++) {
            float x = 10 + (i % 4) * 78, y = 44 + (i / 4) * 58 - gScroll;
            addR(F_TOOL_BASE + i, x, y, 72, 52);
        }
        break;
    case P_BADGES:
        addR(F_P_CLOSE, 11, 7, 34, 34);
        for (int i = 0; i < NBADGE; i++) {
            float cx = 56 + badgeCol[i] * 104;
            addR(F_BADGE_BASE + i, cx - 30, badgeY[i] - gScroll, 60, 70);
        }
        break;
    case P_FILES:
        addR(F_P_CLOSE, 11, 7, 34, 34);
        for (int i = 0; i < nfiles; i++) addR(F_FILE_BASE + i, 12, 44 + i * 28 - gScroll, 296, 24);
        break;
    case P_VOICE:
        addR(F_P_CLOSE, 11, 7, 34, 34);
        addR(F_V_TALK, 126, 70, 68, 68);
        addR(F_V_KB, 40, 200, 240, 32);
        break;
    case P_CAMERA:
        addR(F_P_CLOSE, 11, 7, 34, 34);
        addR(F_CAM_SHOT, 20, 200, 130, 30);
        if (haveShot) addR(F_CAM_SEND, 166, 200, 134, 30);
        break;
    case P_ATTACH:
        addR(F_P_CLOSE, 11, 7, 34, 34);
        addR(F_ATT_CAM, 16, 60, 288, 36);
        addR(F_ATT_PHOTO, 16, 104, 288, 36);
        addR(F_ATT_FILE, 16, 148, 288, 36);
        break;
    default: break;
    }
}

static int defFocus(Page p)
{
    switch (p) {
    case P_CHAT:     return F_INPUT;
    case P_MENU:     return F_M_TOOLS;
    case P_PROFILE:  return profTab ? F_P_TAB1 : F_P_TAB0;
    case P_TOOLS:    return F_TOOL_BASE;
    case P_BADGES:   return F_BADGE_BASE;
    case P_FILES:    return nfiles ? F_FILE_BASE : F_P_CLOSE;
    case P_VOICE:    return F_V_TALK;
    case P_CAMERA:   return F_CAM_SHOT;
    case P_ATTACH:   return F_ATT_CAM;
    default:         return F_NONE;
    }
}

static void setPage(Page p)
{
    if (page == P_CAMERA && p != P_CAMERA) camera_close();
    page = p;
    focus = defFocus(p);
    gScroll = 0;
}

/* dir: 1 up, 2 down, 3 left, 4 right */
static void moveFocus(int dir)
{
    buildRects();
    int cur = -1;
    for (int i = 0; i < nfr; i++) if (fr[i].id == focus) cur = i;
    if (cur < 0) { if (nfr) focus = fr[0].id; return; }
    float cx = fr[cur].x + fr[cur].w / 2, cy = fr[cur].y + fr[cur].h / 2;
    int best = -1; float bs = 1e9f;
    for (int i = 0; i < nfr; i++) {
        if (i == cur) continue;
        float dx = fr[i].x + fr[i].w / 2 - cx, dy = fr[i].y + fr[i].h / 2 - cy;
        float along, perp;
        if      (dir == 1) { along = -dy; perp = fabsf(dx); }
        else if (dir == 2) { along =  dy; perp = fabsf(dx); }
        else if (dir == 3) { along = -dx; perp = fabsf(dy); }
        else               { along =  dx; perp = fabsf(dy); }
        if (along < 4) continue;
        float sc = along + 3 * perp;
        if (sc < bs) { bs = sc; best = i; }
    }
    if (best >= 0) focus = fr[best].id;
}

/* After the focus moves, scroll the body so the focused item is on screen. */
static void keepVisible(void)
{
    if (!scrollPage() || focus == F_P_CLOSE) return;
    buildRects();
    for (int i = 0; i < nfr; i++) {
        if (fr[i].id != focus) continue;
        float top = fr[i].y, bot = fr[i].y + fr[i].h;
        if (top < BODY_T) gScroll -= BODY_T - top;
        else if (bot > BODY_B) gScroll += bot - BODY_B;
        clampG();
        buildRects();
        break;
    }
}

/* ---------- bottom screen ---------- */
static void closeBtn(void)
{
    C2D_DrawCircleSolid(28, 24, 0.2f, 17, cAccent);
    C2D_DrawLine(21, 17, cWhite, 35, 31, cWhite, 2.5f, 0.3f);
    C2D_DrawLine(35, 17, cWhite, 21, 31, cWhite, 2.5f, 0.3f);
}

/* Header strip for the scrolling / sub pages. Draw first, body goes under the header. */
static void drawHeader(const char *title, const char *right)
{
    C2D_DrawRectSolid(0, 0, 0.1f, 320, BODY_T, cBg);
    fring(F_P_CLOSE, 11, 7, 34, 34, 17);
    closeBtn();
    txtc(title, 160, 11, 0.6f, cWhite);
    if (right) txtr(right, 306, 13, 0.42f, cMuted);
}

static void headerButtons(void)
{
    fring(F_MENU, 10, 10, 36, 36, 18);
    fring(F_PRIV, 274, 10, 36, 36, 18);
    C2D_DrawCircleSolid(28, 28, 0.2f, 18, cCard2);
    C2D_DrawRectSolid(19, 23, 0.3f, 18, 3, cWhite);
    C2D_DrawRectSolid(19, 31, 0.3f, 18, 3, cWhite);
    C2D_DrawCircleSolid(292, 28, 0.2f, 18, cCard2);
    u32 col = privateMode ? cAccent : cWhite;
    for (int k = 0; k < 10; k++) {
        float a = k * 0.628f;
        C2D_DrawCircleSolid(292 + cosf(a) * 9, 28 + sinf(a) * 9, 0.3f, 1.6f, col);
    }
}

static void row(float y, const char *label, const char *value)
{
    glassCard(16, y, 288, 36, 12, 0.2f);
    txt(label, 30, y + 9, 0.52f, cWhite);
    if (value) txtr(value, 292, y + 10, 0.45f, cMuted);
}

static void drawChatBottom(void)
{
    headerButtons();
    if (nmsg == 0) {
        if (!cfg_ready(&cfg)) {
            glassCard(16, 60, 288, 100, 16, 0.2f);
            txtc("Not connected yet", 160, 70, 0.6f, cWhite);
            txtc("Set a host in Settings > Connection.", 160, 96, 0.42f, cMuted);
            fring(F_SETUP, 80, 122, 160, 28, 14);
            rrect(80, 122, 160, 28, 14, cAccent, 0.3f);
            txtc("Open Settings", 160, 127, 0.5f, cWhite);
        } else {
            static const unsigned char IC[3][3] = { {255,149,0}, {200,160,110}, {150,150,160} };
            for (int i = 0; i < 3; i++) {
                float y = 62 + i * 34;
                fring(F_SUG0 + i, 16, y, 288, 30, 10);
                C2D_DrawCircleSolid(34, y + 15, 0.3f, 8, CLR(IC[i][0], IC[i][1], IC[i][2]));
                txt(SUGG[i], 52, y + 7, 0.5f, cWhite);
            }
        }
    } else {
        txtc("Up/Down scrolls the chat", 160, 100, 0.42f, cMuted);
    }

    if (attKind) {
        fring(F_CHIP, 8, 168, 304, 20, 10);
        glassCard(8, 168, 304, 20, 10, 0.2f);
        char b[96];
        snprintf(b, sizeof b, "%s: %.40s  (A removes)", attKind == 1 ? "Photo" : "File", attName);
        txt(b, 18, 171, 0.42f, cWhite);
    }

    /* input row: attach, text field, mic, send */
    fring(F_ATTACH, 8, 192, 36, 40, 18);
    C2D_DrawCircleSolid(26, 212, 0.3f, 15, cCard2);
    C2D_DrawRectSolid(19, 211, 0.35f, 14, 2, cWhite);
    C2D_DrawRectSolid(25, 205, 0.35f, 2, 14, cWhite);

    fring(F_INPUT, 48, 192, 196, 40, 20);
    glassCard(48, 192, 196, 40, 20, 0.2f);
    txt(privateMode ? "Private chat" : "Ask anything", 62, 203, 0.55f, cMuted);

    fring(F_MIC, 248, 192, 32, 40, 16);
    C2D_DrawCircleSolid(264, 212, 0.3f, 15, cCard2);
    rrect(260, 202, 8, 14, 4, cWhite, 0.35f);
    C2D_DrawRectSolid(263, 216, 0.35f, 2, 5, cWhite);
    C2D_DrawRectSolid(258, 220, 0.35f, 12, 2, cWhite);

    C2D_DrawCircleSolid(294, 212, 0.3f, 15, running ? cTrack : cAccent);
    if (running) {
        txtc("...", 294, 205, 0.6f, cWhite);
    } else {
        C2D_DrawTriangle(294, 203, cWhite, 287, 212, cWhite, 301, 212, cWhite, 0.5f);
        C2D_DrawRectSolid(291, 211, 0.5f, 6, 8, cWhite);
    }
}

static void drawMenu(void)
{
    txt("EcoGPT", 16, 8, 0.95f, cWhite);
    fring(F_M_TOOLS, 16, 64, 288, 36, 12);
    row(64, "Tools", ">");
    fring(F_M_IMPACT, 16, 108, 288, 36, 12);
    row(108, "Impact", ">");
    fring(F_M_SETTINGS, 16, 152, 288, 36, 12);
    row(152, "Settings", ">");

    fring(F_M_CHAT, 14, 194, 110, 36, 18);
    rrect(14, 194, 110, 36, 18, cAccent, 0.2f);
    txtc("Chat", 69, 204, 0.6f, cWhite);

    fring(F_M_VOICE, 130, 194, 110, 36, 18);
    glassCard(130, 194, 110, 36, 18, 0.2f);
    txtc("Voice chat", 185, 205, 0.5f, cWhite);

    fring(F_M_GEAR, 254, 194, 52, 36, 18);
    glassCard(254, 194, 52, 36, 18, 0.2f);
    C2D_DrawCircleSolid(280, 212, 0.25f, 10, cCard2);
    C2D_DrawCircleSolid(280, 212, 0.3f, 5, cWhite);
    C2D_DrawCircleSolid(280, 212, 0.4f, 2.5f, cCard2);
}

static void drawProfileHeader(void)
{
    fring(F_P_CLOSE, 11, 7, 34, 34, 17);
    closeBtn();
    glassCard(52, 8, 260, 32, 16, 0.2f);
    rrect(profTab ? 184 : 54, 10, 124, 28, 14, cTrack, 0.25f);
    fring(F_P_TAB0, 54, 10, 124, 28, 14);
    fring(F_P_TAB1, 184, 10, 124, 28, 14);
    miniTree(84, 22, 9);
    txt("Impact", 98, 15, 0.5f, cWhite);
    C2D_DrawCircleSolid(206, 20, 0.4f, 3, cWhite);
    C2D_DrawCircleSolid(214, 22, 0.4f, 3, cWhite);
    rrect(202, 25, 16, 6, 3, cWhite, 0.4f);
    txt("Friends", 224, 15, 0.5f, cWhite);
}

static void drawImpact(void)
{
    int trees = chats / CHATS_PER_TREE, prog = chats % CHATS_PER_TREE;
    glassCard(16, 48, 288, 108, 16, 0.2f);
    char b[16];
    snprintf(b, sizeof b, "%d", trees);
    txt(b, 28, 50, 1.6f, cWhite);
    float nx = 28 + txtw(b, 1.6f) + 14;
    miniTree(nx + 11, 74, 20);
    txt("Trees planted", 28, 104, 0.6f, cWhite);
    rrect(28, 132, 264, 12, 6, cTrack, 0.25f);
    float fw = 264.0f * prog / CHATS_PER_TREE;
    if (fw > 12) rrect(28, 132, fw, 12, 6, cBar, 0.3f);
    C2D_DrawRectSolid(28 + fw - 1, 130, 0.35f, 3, 16, cWhite);

    /* badge summary; the full sheet is the Badges page */
    fring(F_P_BADGES, 16, 164, 288, 68, 14);
    glassCard(16, 164, 288, 68, 14, 0.2f);
    txt("Badges", 30, 172, 0.55f, cWhite);
    char b2[32];
    snprintf(b2, sizeof b2, "%d/%d collected", countBadges(), NBADGE);
    txtr(b2, 292, 174, 0.42f, cMuted);
    int shown = 0;
    for (int i = 0; i < NBADGE && shown < 4; i++)
        if (badgeMet(i)) { drawBadgeIcon(i, 44 + shown * 46.0f, 212, 13, true); shown++; }
    for (; shown < 4; shown++) drawBadgeIcon(0, 44 + shown * 46.0f, 212, 13, false);
    txtr("View all  >", 292, 205, 0.42f, cMuted);
}

static void pill(float cx, float y, int n, u32 bg)
{
    char b[16];
    snprintf(b, sizeof b, "%d", n);
    float w = txtw(b, 0.5f) + 30;
    rrect(cx - w / 2, y, w, 18, 9, bg, 0.3f);
    txt(b, cx - w / 2 + 9, y + 2, 0.5f, cWhite);
    miniTree(cx + w / 2 - 12, y + 7, 8);
}

static void drawFriends(void)
{
    fring(F_P_DROP, 20, 52, 104, 26, 13);
    glassCard(20, 52, 104, 26, 13, 0.25f);
    txt(lbGlobal ? "Global" : "Friends", 34, 58, 0.5f, cWhite);
    C2D_DrawLine(104, 62, cMuted, 108, 66, cMuted, 1.6f, 0.4f);
    C2D_DrawLine(108, 66, cMuted, 112, 62, cMuted, 1.6f, 0.4f);
    fring(F_P_ADD, 176, 52, 128, 26, 13);
    glassCard(176, 52, 128, 26, 13, 0.25f);
    C2D_DrawCircleSolid(194, 61, 0.4f, 3, cBar);
    rrect(189, 65, 11, 6, 3, cBar, 0.4f);
    txt("Add Friend", 208, 58, 0.5f, cWhite);

    u32 gold = CLR(240, 200, 60);
    rrect(20, 206, 92, 26, 8, CLR(84, 84, 90), 0.25f);   txtc("2", 66, 208, 0.8f, CLR(225, 225, 232));
    rrect(114, 192, 92, 40, 8, CLR(100, 86, 42), 0.25f); txtc("1", 160, 196, 1.0f, gold);
    rrect(208, 214, 92, 18, 8, CLR(104, 72, 50), 0.25f); txtc("3", 254, 213, 0.6f, CLR(235, 160, 110));

    if (!lbGlobal) {
        C2D_DrawRectSolid(150, 94, 0.4f, 20, 5, gold);
        C2D_DrawTriangle(150, 94, gold, 154, 94, gold, 150, 88, gold, 0.4f);
        C2D_DrawTriangle(156, 94, gold, 164, 94, gold, 160, 86, gold, 0.4f);
        C2D_DrawTriangle(166, 94, gold, 170, 94, gold, 170, 88, gold, 0.4f);
        hexagon(160, 120, 22, gold, 0.3f);
        hexagon(160, 120, 19, cCard2, 0.35f);
        person(160, 122, 22, cMuted, 0.4f);
        rrect(142, 146, 36, 16, 8, cAccent, 0.3f);
        txtc("You", 160, 147, 0.4f, cWhite);
        pill(160, 166, chats / CHATS_PER_TREE, cCard2);
        hexDashed(66, 172, 18, cTrack, 0.3f);   person(66, 174, 18, cTrack, 0.3f);
        hexDashed(254, 190, 18, cTrack, 0.3f);  person(254, 192, 18, cTrack, 0.3f);
    } else {
        hexDashed(160, 126, 22, cTrack, 0.3f);  person(160, 128, 22, cTrack, 0.3f);
        hexDashed(66, 172, 18, cTrack, 0.3f);   person(66, 174, 18, cTrack, 0.3f);
        hexDashed(254, 190, 18, cTrack, 0.3f);  person(254, 192, 18, cTrack, 0.3f);
        txtc("Global ranking needs EcoGPT's API", 160, 86, 0.42f, cMuted);
    }
}

static void drawProfile(void)
{
    drawProfileHeader();
    if (profTab == 0) drawImpact(); else drawFriends();
}

/* ---------- tools page ---------- */
static void tileLabel(const char *name, float cx, float cy, u32 col)
{
    if (txtw(name, 0.36f) <= 66) { txtc(name, cx, cy - 6, 0.36f, col); return; }
    const char *sp = strchr(name, ' ');
    if (!sp) { txtc(name, cx, cy - 6, 0.36f, col); return; }
    char a[32];
    int n = (int)(sp - name); if (n > 31) n = 31;
    memcpy(a, name, n); a[n] = 0;
    txtc(a, cx, cy - 13, 0.36f, col);
    txtc(sp + 1, cx, cy + 1, 0.36f, col);
}

static void drawTools(void)
{
    drawHeader("Tools", NULL);
    for (int i = 0; i < NTOOLS; i++) {
        float x = 10 + (i % 4) * 78, y = 44 + (i / 4) * 58 - gScroll;
        if (y < BODY_T || y + 52 > BODY_B) continue;
        bool live = TOOLS[i].act != A_NONE;
        fring(F_TOOL_BASE + i, x, y, 72, 52, 14);
        if (live) rrect(x, y, 72, 52, 14, CLR(ACC[i % 5][0], ACC[i % 5][1], ACC[i % 5][2]), 0.2f);
        else      rrect(x, y, 72, 52, 14, cCard2, 0.2f);
        tileLabel(TOOLS[i].name, x + 36, y + 26, live ? cWhite : cMuted);
    }
}

/* ---------- badges page ---------- */
static void drawBadges(void)
{
    char right[32];
    snprintf(right, sizeof right, "%d/%d collected", countBadges(), NBADGE);
    drawHeader("Badges", right);
    for (int c = 0; c < 5; c++) {
        float hy = hdrY[c] - gScroll;
        if (hy >= BODY_T && hy + 20 <= BODY_B) txtc(CATS[c], 160, hy + 2, 0.5f, cWhite);
    }
    for (int i = 0; i < NBADGE; i++) {
        float cx = 56 + badgeCol[i] * 104, y = badgeY[i] - gScroll;
        if (y < BODY_T || y + 70 > BODY_B) continue;
        bool got = badgeMet(i);
        fring(F_BADGE_BASE + i, cx - 30, y, 60, 70, 12);
        drawBadgeIcon(i, cx, y + 26, 26, got);
        txtc(BADGES[i].name, cx, y + 56, 0.36f, got ? cWhite : cMuted);
    }
}

/* ---------- voice page ---------- */
static void drawVoice(void)
{
    drawHeader("Voice chat", NULL);
    u32 ringC = listening ? cAccent : cCard2;
    fring(F_V_TALK, 126, 70, 68, 68, 34);
    C2D_DrawCircleSolid(160, 104, 0.3f, 34, ringC);
    rrect(153, 88, 14, 22, 7, cWhite, 0.35f);
    C2D_DrawRectSolid(158, 110, 0.35f, 4, 8, cWhite);
    C2D_DrawRectSolid(150, 116, 0.35f, 20, 2, cWhite);

    for (int k = 0; k < 15; k++) {
        float hgt = 4;
        if (listening) hgt = 4 + (float)(((frameNo / 3) + k * 5) % 13) * 1.6f;
        float x = 97 + k * 9;
        C2D_DrawRectSolid(x, 182 - hgt / 2, 0.4f, 5, hgt, listening ? cAccent : cTrack);
    }
    txtc(listening ? "Listening..." : "Tap the mic to talk", 160, 146, 0.5f, cWhite);
    if (voiceNote[0]) txtc(voiceNote, 160, 160, 0.38f, cMuted);

    fring(F_V_KB, 40, 200, 240, 32, 16);
    rrect(40, 200, 240, 32, 16, cCard2, 0.2f);
    txtc("Type instead", 160, 209, 0.5f, cWhite);
}

/* ---------- camera page ---------- */
static u32 rgb565(u16 p)
{
    int r = ((p >> 11) & 31) * 255 / 31, g = ((p >> 5) & 63) * 255 / 63, b = (p & 31) * 255 / 31;
    return CLR(r, g, b);
}

static void drawCamera(void)
{
    drawHeader("Camera", NULL);
    if (haveShot) {
        const u16 *px = camera_frame();
        const int GX = 33, GY = 24;
        float bw = 200.0f / GX, bh = 150.0f / GY;
        for (int gy = 0; gy < GY; gy++)
            for (int gx = 0; gx < GX; gx++) {
                u16 p = px[(gy * 10) * CAM_W + gx * 12];
                C2D_DrawRectSolid(60 + gx * bw, 40 + gy * bh, 0.2f, bw + 0.6f, bh + 0.6f, rgb565(p));
            }
    } else {
        txtc("No photo yet", 160, 100, 0.55f, cMuted);
    }
    fring(F_CAM_SHOT, 20, 200, 130, 30, 15);
    rrect(20, 200, 130, 30, 15, cCard2, 0.2f);
    txtc(haveShot ? "Retake" : "Take photo", 85, 209, 0.5f, cWhite);
    if (haveShot) {
        fring(F_CAM_SEND, 166, 200, 134, 30, 15);
        rrect(166, 200, 134, 30, 15, cAccent, 0.2f);
        txtc("Send to Eco", 233, 209, 0.5f, cWhite);
    }
}

/* ---------- attach sheet ---------- */
static void drawAttach(void)
{
    drawHeader("Attach", NULL);
    static const char *L[3] = { "Take a photo", "Photo from SD card", "File from SD card" };
    static const int IDS[3] = { F_ATT_CAM, F_ATT_PHOTO, F_ATT_FILE };
    for (int i = 0; i < 3; i++) {
        float y = 60 + i * 44;
        fring(IDS[i], 16, y, 288, 36, 12);
        glassCard(16, y, 288, 36, 12, 0.2f);
        txt(L[i], 30, y + 9, 0.52f, cWhite);
        txtr(">", 292, y + 10, 0.45f, cMuted);
    }
    txtc("Photos and files are read from", 160, 196, 0.4f, cMuted);
    txtc("sdmc:/3ds/ecogpt/uploads", 160, 210, 0.4f, cMuted);
}

/* ---------- file / photo list ---------- */
static void drawFiles(void)
{
    drawHeader(fileMode == 0 ? "Photos" : fileMode == 1 ? "PDFs" : "Files", NULL);
    if (!nfiles) {
        txtc("Nothing here yet.", 160, 90, 0.55f, cWhite);
        txtc("Copy files to sdmc:/3ds/ecogpt/uploads", 160, 112, 0.38f, cMuted);
        return;
    }
    for (int i = 0; i < nfiles; i++) {
        float y = 44 + i * 28 - gScroll;
        if (y < BODY_T || y + 24 > BODY_B) continue;
        fring(F_FILE_BASE + i, 12, y, 296, 24, 8);
        glassCard(12, y, 296, 24, 8, 0.2f);
        char b[48];
        snprintf(b, sizeof b, "%.42s", fileNames[i]);
        txt(b, 24, y + 6, 0.42f, cWhite);
    }
}

static void drawHelp(void)
{
    closeBtn();
    txtc("Controls", 160, 12, 0.7f, cWhite);
    static const char *L[7][2] = {
        { "Circle Pad", "Move around the screen" },
        { "A", "Select" },
        { "B", "Back" },
        { "D-Pad Up/Down", "Scroll the chat" },
        { "X / Y", "New chat / Profile" },
        { "Select", "Menu" },
        { "Start", "Exit" }
    };
    for (int i = 0; i < 7; i++) {
        float y = 52 + i * 26;
        glassCard(16, y, 288, 22, 8, 0.2f);
        txt(L[i][0], 26, y + 4, 0.45f, cWhite);
        txtr(L[i][1], 296, y + 4, 0.42f, cMuted);
    }
}

/* ---------- settings ---------- */
static void layoutSettings(void)
{
    float y = 0;
    for (int i = 0; i < NSET; i++) { setY[i] = y; y += SET[i].type ? 34 : 24; }
    setH = y;
}
static void clampScroll(void)
{
    float mx = setH - 194 + 4;
    if (mx < 0) mx = 0;
    if (setScroll > mx) setScroll = mx;
    if (setScroll < 0) setScroll = 0;
}
static void ensureVisible(void)
{
    float top = setY[setSel];
    if (setSel > 0 && SET[setSel - 1].type == 0) top = setY[setSel - 1];
    if (top < setScroll) setScroll = top;
    if (setY[setSel] + 30 - setScroll > 194) setScroll = setY[setSel] + 30 - 194;
    clampScroll();
}
static void settingsMove(int d)
{
    int j = setSel;
    if (d == 1) { do j--; while (j >= 0 && SET[j].type == 0); }
    else if (d == 2) { do j++; while (j < NSET && SET[j].type == 0); }
    else return;
    if (j >= 0 && j < NSET) setSel = j;
    ensureVisible();
}
static void openSettingsAt(int id)
{
    setPage(P_SETTINGS);
    for (int i = 0; i < NSET; i++) if (SET[i].id == id) setSel = i;
    ensureVisible();
}

static void settingValue(int id, char *v, size_t cap, bool *toggle, bool *on)
{
    v[0] = 0; *toggle = false; *on = false;
    switch (id) {
        case S_NAME:    snprintf(v, cap, "%.18s", cfg.name); break;
        case S_ACCENT:  snprintf(v, cap, "%s", ACC_N[accent]); break;
        case S_TEXT:    snprintf(v, cap, "%s", TSZ_N[tsize]); break;
        case S_PRIVATE: *toggle = true; *on = privateMode; break;
        case S_REPLY: {
            int k = 1;
            for (int i = 0; i < 3; i++) if (cfg.max_tokens == RL[i]) k = i;
            snprintf(v, cap, "%s", RL_N[k]);
            break;
        }
        case S_INSTR: {
            Config d; cfg_defaults(&d);
            snprintf(v, cap, "%s", strcmp(d.system, cfg.system) ? "Custom" : "Default");
            break;
        }
        case S_CLEAR:   snprintf(v, cap, ">"); break;
        case S_TREES:   snprintf(v, cap, "%d", chats / CHATS_PER_TREE); break;
        case S_RESET:   snprintf(v, cap, "%s", resetArm > 0 ? "Tap again" : ">"); break;
        case S_TEST:    snprintf(v, cap, "%s", testState == 1 ? "Testing..." : testState == 2 ? "Connected" : testState == 3 ? "Failed" : ">"); break;
        case S_HOST:    snprintf(v, cap, "%.18s", cfg.host[0] ? cfg.host : "Not set"); break;
        case S_KEY: {
            size_t n = strlen(cfg.key);
            if (!n) snprintf(v, cap, "Not set");
            else { if (n > 8) n = 8; memset(v, '*', n); v[n] = 0; }
            break;
        }
        case S_MODEL:   snprintf(v, cap, "%.18s", cfg.model[0] ? cfg.model : "None"); break;
        case S_VERIFY:  *toggle = true; *on = cfg.verify; break;
        case S_CONTROLS: snprintf(v, cap, ">"); break;
        case S_VERSION: snprintf(v, cap, "%s", VERSION); break;
    }
}

static void drawSettings(void)
{
    for (int i = 0; i < NSET; i++) {
        float sy = 46 + setY[i] - setScroll;
        if (SET[i].type == 0) {
            if (sy >= 40 && sy + 14 <= 240) txt(SET[i].label, 24, sy + 4, 0.42f, cMuted);
            continue;
        }
        if (sy < 44 || sy + 30 > 240) continue;
        if (showFocus && i == setSel) routline(13.5f, sy - 2.5f, 293, 35, 12, 2.0f, cWhite, 0.6f);
        glassCard(16, sy, 288, 30, 10, 0.2f);
        txt(SET[i].label, 28, sy + 7, 0.5f, cWhite);
        char v[32]; bool tg, on;
        settingValue(SET[i].id, v, sizeof v, &tg, &on);
        if (tg) {
            rrect(256, sy + 7, 36, 16, 8, on ? cBar : cTrack, 0.3f);
            C2D_DrawCircleSolid(on ? 284 : 264, sy + 15, 0.4f, 6, cWhite);
        } else if (SET[i].id == S_ACCENT) {
            txtr(v, 274, sy + 8, 0.45f, cMuted);
            C2D_DrawCircleSolid(285, sy + 15, 0.4f, 5, cAccent);
        } else if (v[0]) {
            txtr(v, 292, sy + 8, 0.45f, (SET[i].id == S_TEST && testState == 3) ? CLR(255, 90, 80) : cMuted);
        }
    }
    C2D_DrawRectSolid(0, 0, 0.7f, 320, 44, cBg);
    closeBtn();
    txtc("Settings", 160, 12, 0.7f, cWhite);
}

static void drawToast(void)
{
    if (toastT <= 0) return;
    char a[48] = {0}, b[48] = {0};
    int n = (int)strlen(toastMsg);
    if (n <= 44) memcpy(a, toastMsg, n);
    else {
        int cut = 44;
        for (int i = 44; i > 20; i--) if (toastMsg[i] == ' ') { cut = i; break; }
        memcpy(a, toastMsg, cut);
        snprintf(b, sizeof b, "%.44s", toastMsg + cut + (toastMsg[cut] == ' ' ? 1 : 0));
    }
    rrect(12, 188, 296, 44, 14, GLA(30, 30, 36, 235), 0.97f);
    textZ = 0.99f;
    txtc(a, 160, b[0] ? 193 : 202, 0.45f, cWhite);
    if (b[0]) txtc(b, 160, 209, 0.45f, cWhite);
    textZ = 0.95f;
}

static void drawBottom(void)
{
    bgGlow();
    switch (page) {
    case P_CHAT:     drawChatBottom(); break;
    case P_MENU:     drawMenu(); break;
    case P_PROFILE:  drawProfile(); break;
    case P_SETTINGS: drawSettings(); break;
    case P_HELP:     drawHelp(); break;
    case P_TOOLS:    drawTools(); break;
    case P_VOICE:    drawVoice(); break;
    case P_CAMERA:   drawCamera(); break;
    case P_FILES:    drawFiles(); break;
    case P_BADGES:   drawBadges(); break;
    case P_ATTACH:   drawAttach(); break;
    }
    drawToast();
}

/* ---------- actions ---------- */
static void worker(void *arg)
{
    Job *j = arg;
    j->ok = backend_chat(&j->cfg, j->hist, j->n, j->reply, sizeof j->reply) == 0;
    j->done = 1;
}

static bool spawnJob(void)
{
    job.cfg = cfg;
    job.done = 0;
    job.reply[0] = 0;
    s32 prio = 0;
    svcGetThreadPriority(&prio, CUR_THREAD_HANDLE);
    th = threadCreate(worker, &job, 128 * 1024, prio - 1, -2, false);
    if (!th) return false;
    running = true;
    return true;
}

static void startJob(void)
{
    int cnt = nmsg < 12 ? nmsg : 12;
    int off = nmsg - cnt;
    if (msgs[off].role == 1 && cnt > 1) { off++; cnt--; }
    for (int i = 0; i < cnt; i++) job.hist[i] = msgs[off + i];
    job.n = cnt;
    job.test = 0;
    if (!spawnJob()) addMsg(1, "[error] Could not start the network thread.");
}

static void startTest(void)
{
    if (running) return;
    if (!cfg_ready(&cfg)) { toast("Set a host first."); return; }
    job.hist[0].role = 0;
    snprintf(job.hist[0].text, MSG_LEN, "Reply with the single word OK.");
    job.n = 1;
    job.test = 1;
    if (spawnJob()) testState = 1; else toast("Could not start the network thread.");
}

static void submitPrompt(const char *s)
{
    if (!cfg_ready(&cfg)) { toast("Set a host in Connection first."); openSettingsAt(S_HOST); return; }
    if (attKind) {
        char err[128] = {0};
        if (backend_send_attachment(&cfg, attPath, attKind == 1, err, sizeof err) != 0) {
            toast(err[0] ? err : "Couldn't send the attachment.");
            return;
        }
        char m[MSG_LEN];
        snprintf(m, sizeof m, "[%s: %s] %s", attKind == 1 ? "Photo" : "File", attName, s);
        addMsg(0, m);
        attKind = 0;
    } else {
        addMsg(0, s);
    }
    startJob();
}

static bool editText(const char *hint, char *buf, size_t cap, int maxLen, bool secret)
{
    static char tmp[600];
    snprintf(tmp, sizeof tmp, "%s", buf);
    SwkbdState s;
    swkbdInit(&s, SWKBD_TYPE_NORMAL, 2, maxLen);
    swkbdSetHintText(&s, hint);
    swkbdSetInitialText(&s, tmp);
    swkbdSetValidation(&s, SWKBD_ANYTHING, 0, 0);
    swkbdSetButton(&s, SWKBD_BUTTON_LEFT, "Cancel", false);
    swkbdSetButton(&s, SWKBD_BUTTON_RIGHT, "Save", true);
    if (secret) swkbdSetPasswordMode(&s, SWKBD_PASSWORD_HIDE_DELAY);
    if (swkbdInputText(&s, tmp, sizeof tmp) != SWKBD_BUTTON_RIGHT) return false;
    for (char *p = tmp; *p; p++) if (*p == '\n' || *p == '\r') *p = ' ';
    snprintf(buf, cap, "%s", tmp);
    return true;
}

static void sendFromKeyboard(void)
{
    static char buf[MSG_LEN];
    buf[0] = 0;
    SwkbdState s;
    swkbdInit(&s, SWKBD_TYPE_NORMAL, 2, 500);
    swkbdSetHintText(&s, privateMode ? "Private chat" : "Ask anything");
    swkbdSetButton(&s, SWKBD_BUTTON_LEFT, "Cancel", false);
    swkbdSetButton(&s, SWKBD_BUTTON_RIGHT, "Send", true);
    swkbdSetFeatures(&s, SWKBD_MULTILINE);
    if (swkbdInputText(&s, buf, sizeof buf) == SWKBD_BUTTON_RIGHT && buf[0]) submitPrompt(buf);
}

static void finishJob(void)
{
    threadJoin(th, U64_MAX);
    threadFree(th);
    th = NULL;
    running = false;
    if (job.test) {
        testState = job.ok ? 2 : 3;
        if (job.ok) toast("Connected.");
        else { char e[120]; snprintf(e, sizeof e, "%.100s", job.reply); toast(e); }
        return;
    }
    if (job.ok) {
        addMsg(1, job.reply);
        if (!privateMode) { chats++; touchStreak(); saveStats(); }
    } else {
        char e[MSG_LEN];
        snprintf(e, sizeof e, "[error] %s", job.reply);
        addMsg(1, e);
    }
}

static void newChat(void) { nmsg = 0; nl = 0; scrollOff = 0; dirty = true; }

/* Accepts "https://host/path" too: splits it into host and path. */
static void normHost(void)
{
    char *h = cfg.host;
    if (!strncmp(h, "https://", 8)) memmove(h, h + 8, strlen(h + 8) + 1);
    else if (!strncmp(h, "http://", 7)) memmove(h, h + 7, strlen(h + 7) + 1);
    char *sl = strchr(h, '/');
    if (sl) { snprintf(cfg.path, sizeof cfg.path, "%s", sl); *sl = 0; }
}

static void settingsActivate(int id)
{
    switch (id) {
        case S_NAME:
            if (editText("Companion name", cfg.name, sizeof cfg.name, 24, false)) {
                if (!cfg.name[0]) strcpy(cfg.name, "Eco");
                flags |= FL_NAME; saveStats();
                saveCfg();
            }
            break;
        case S_ACCENT: accent = (accent + 1) % 5; setAccent(); saveStats(); break;
        case S_TEXT:   tsize = (tsize + 1) % 3; setTextSize(); saveStats(); break;
        case S_PRIVATE:
            privateMode = !privateMode;
            if (privateMode) { flags |= FL_PRIV; saveStats(); }
            newChat();
            break;
        case S_REPLY: {
            int k = 1;
            for (int i = 0; i < 3; i++) if (cfg.max_tokens == RL[i]) k = i;
            cfg.max_tokens = RL[(k + 1) % 3];
            saveCfg();
            break;
        }
        case S_INSTR:
            if (editText("Custom instructions (empty = default)", cfg.system, sizeof cfg.system, 400, false)) {
                if (!cfg.system[0]) { Config d; cfg_defaults(&d); snprintf(cfg.system, sizeof cfg.system, "%s", d.system); }
                flags |= FL_INSTR; saveStats();
                saveCfg();
            }
            break;
        case S_CLEAR: newChat(); toast("Chat cleared."); break;
        case S_TREES: toast("1 tree per 200 chats, counted on this 3DS only."); break;
        case S_RESET:
            if (resetArm > 0) { chats = 0; saveStats(); resetArm = 0; toast("Impact reset."); }
            else resetArm = 180;
            break;
        case S_TEST: startTest(); break;
        case S_HOST:
            if (editText("Host, e.g. api.example.com", cfg.host, sizeof cfg.host, 120, false)) { normHost(); testState = 0; saveCfg(); }
            break;
        case S_KEY:
            if (editText("API key", cfg.key, sizeof cfg.key, 250, true)) { testState = 0; saveCfg(); }
            break;
        case S_MODEL:
            if (editText("Model (optional)", cfg.model, sizeof cfg.model, 90, false)) { testState = 0; saveCfg(); }
            break;
        case S_VERIFY: cfg.verify = !cfg.verify; saveCfg(); break;
        case S_CONTROLS: page = P_HELP; break;
        case S_VERSION: toast("EcoGPT for 3DS " VERSION "  (UI prototype)"); break;
    }
}

/* ---------- SD card lists (photos / files) ---------- */
static bool extOK(const char *n, int mode)
{
    if (mode == 2) return true;
    const char *dot = strrchr(n, '.');
    if (!dot) return false;
    char e[8] = {0};
    int k = 0;
    for (const char *p = dot + 1; *p && k < 7; p++) e[k++] = (char)tolower((unsigned char)*p);
    if (mode == 0) return !strcmp(e, "bmp") || !strcmp(e, "png") || !strcmp(e, "jpg") || !strcmp(e, "jpeg");
    return !strcmp(e, "pdf");
}

static void listDir(int mode)
{
    nfiles = 0;
    DIR *d = opendir(UPLOAD_DIR);
    if (!d) return;
    struct dirent *e;
    while (nfiles < NFILES && (e = readdir(d)) != NULL) {
        if (e->d_name[0] == '.') continue;
        if (!extOK(e->d_name, mode)) continue;
        char full[320];
        snprintf(full, sizeof full, "%s/%s", UPLOAD_DIR, e->d_name);
        struct stat st;
        if (stat(full, &st) == 0 && S_ISDIR(st.st_mode)) continue;
        snprintf(fileNames[nfiles], sizeof fileNames[0], "%s", e->d_name);
        nfiles++;
    }
    closedir(d);
}

static void openFiles(int mode, Page from)
{
    ensureDirs();
    fileMode = mode;
    listDir(mode);
    backPage = from;
    setPage(P_FILES);
}

/* Where the B button and the close button go. */
static Page backOf(Page p)
{
    switch (p) {
    case P_HELP:     return P_SETTINGS;
    case P_SETTINGS: return P_CHAT;
    case P_PROFILE:  return P_CHAT;
    case P_MENU:     return P_CHAT;
    case P_TOOLS:    return P_MENU;
    case P_BADGES:   return P_PROFILE;
    case P_VOICE:
    case P_CAMERA:
    case P_FILES:
    case P_ATTACH:   return backPage;
    default:         return P_CHAT;
    }
}

static void openTool(int i)
{
    switch (TOOLS[i].act) {
    case A_CAMERA:
        backPage = P_TOOLS;
        if (camera_open() == 0) { haveShot = false; setPage(P_CAMERA); }
        else toast("Camera isn't available.");
        break;
    case A_VOICE:  backPage = P_TOOLS; setPage(P_VOICE); break;
    case A_PHOTOS: openFiles(0, P_TOOLS); break;
    case A_PDFS:   openFiles(1, P_TOOLS); break;
    default:       toast("Needs EcoGPT's API. Not built yet."); break;
    }
}

static void pickFile(int i)
{
    if (i < 0 || i >= nfiles) return;
    snprintf(attName, sizeof attName, "%s", fileNames[i]);
    snprintf(attPath, sizeof attPath, "%s/%s", UPLOAD_DIR, fileNames[i]);
    attKind = fileMode == 0 ? 1 : 2;
    if (attKind == 2) { flags |= FL_FILE; saveStats(); }
    setPage(P_CHAT);
    toast("Attached. Send it with your message.");
}

static void badgeInfo(int i)
{
    char b[128];
    snprintf(b, sizeof b, "%s: %s (%s)", BADGES[i].name, BADGES[i].cond, badgeMet(i) ? "unlocked" : "locked");
    toast(b);
}

static void activate(int id)
{
    if (id >= F_TOOL_BASE && id < F_TOOL_BASE + NTOOLS)   { openTool(id - F_TOOL_BASE); return; }
    if (id >= F_BADGE_BASE && id < F_BADGE_BASE + NBADGE) { badgeInfo(id - F_BADGE_BASE); return; }
    if (id >= F_FILE_BASE && id < F_FILE_BASE + NFILES)   { pickFile(id - F_FILE_BASE); return; }
    switch (id) {
        case F_MASCOT:    profTab = 0; setPage(P_PROFILE); break;
        case F_MENU:      setPage(P_MENU); break;
        case F_PRIV:
            privateMode = !privateMode;
            if (privateMode) { flags |= FL_PRIV; saveStats(); }
            newChat();
            break;
        case F_SUG0: case F_SUG1: case F_SUG2:
            if (!running) submitPrompt(SUGG[id - F_SUG0]);
            break;
        case F_INPUT:     if (!running) sendFromKeyboard(); break;
        case F_SETUP:     openSettingsAt(S_HOST); break;
        case F_ATTACH:    backPage = P_CHAT; setPage(P_ATTACH); break;
        case F_MIC:       backPage = P_CHAT; setPage(P_VOICE); break;
        case F_CHIP:      attKind = 0; toast("Attachment removed."); break;
        case F_M_TOOLS:   backPage = P_MENU; setPage(P_TOOLS); break;
        case F_M_IMPACT:  profTab = 0; setPage(P_PROFILE); break;
        case F_M_SETTINGS: case F_M_GEAR: setPage(P_SETTINGS); break;
        case F_M_CHAT:    newChat(); setPage(P_CHAT); break;
        case F_M_VOICE:   backPage = P_MENU; setPage(P_VOICE); break;
        case F_P_CLOSE:   setPage(page == P_PROFILE ? P_CHAT : backOf(page)); break;
        case F_P_TAB0:    profTab = 0; break;
        case F_P_TAB1:    profTab = 1; break;
        case F_P_DROP:    lbGlobal = !lbGlobal; break;
        case F_P_ADD:     toast("Adding friends needs EcoGPT's API."); break;
        case F_P_BADGES:  setPage(P_BADGES); break;
        case F_V_TALK:
            if (!listening) {
                listening = true;
                voiceNote[0] = 0;
                flags |= FL_VOICE; saveStats();
            } else {
                listening = false;
                snprintf(voiceNote, sizeof voiceNote, "Voice input needs EcoGPT's API. Type for now.");
            }
            break;
        case F_V_KB:      setPage(P_CHAT); break;
        case F_CAM_SHOT:
            if (camera_snap() == 0) { haveShot = true; flags |= FL_CAMERA; saveStats(); }
            else toast("Couldn't take the photo.");
            break;
        case F_CAM_SEND:
            if (!haveShot) break;
            ensureDirs();
            shotNo++;
            snprintf(attName, sizeof attName, "cam-%03d.bmp", shotNo);
            snprintf(attPath, sizeof attPath, "%s/%s", UPLOAD_DIR, attName);
            if (camera_save_bmp(attPath) == 0) {
                attKind = 1;
                setPage(P_CHAT);
                toast("Photo ready. Send it with your message.");
            } else {
                toast("Couldn't save the photo to the SD card.");
            }
            break;
        case F_ATT_CAM:
            backPage = P_ATTACH;
            if (camera_open() == 0) { haveShot = false; setPage(P_CAMERA); }
            else toast("Camera isn't available.");
            break;
        case F_ATT_PHOTO: openFiles(0, P_ATTACH); break;
        case F_ATT_FILE:  openFiles(2, P_ATTACH); break;
    }
}

/* Taps on scrolling pages happen on release, so a drag does not activate. */
static void touchActivate(const touchPosition *t)
{
    buildRects();
    for (int i = 0; i < nfr; i++) {
        if (fr[i].id != F_P_CLOSE && (fr[i].y < BODY_T || fr[i].y + fr[i].h > BODY_B)) continue;
        if (hit(t, (int)fr[i].x, (int)fr[i].y, (int)fr[i].w, (int)fr[i].h)) {
            focus = fr[i].id;
            activate(fr[i].id);
            return;
        }
    }
}

/* Circle Pad (and D-Pad) as a direction with key repeat. dpadVert: also use D-Pad up/down. */
static int navDir(u32 kh, bool dpadVert)
{
    static int last = 0, held = 0;
    u32 up = KEY_CPAD_UP | (dpadVert ? KEY_DUP : 0), dn = KEY_CPAD_DOWN | (dpadVert ? KEY_DDOWN : 0);
    u32 lf = KEY_CPAD_LEFT | KEY_DLEFT, rt = KEY_CPAD_RIGHT | KEY_DRIGHT;
    int d = 0;
    if (kh & up) d = 1; else if (kh & dn) d = 2; else if (kh & lf) d = 3; else if (kh & rt) d = 4;
    if (!d) { last = 0; held = 0; return 0; }
    if (d != last) { last = d; held = 1; return d; }
    held++;
    if (held > 14 && (held - 14) % 5 == 0) return d;
    return 0;
}

int main(void)
{
    gfxInitDefault();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();
    httpcInit(0);

    C3D_RenderTarget *top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    C3D_RenderTarget *bot = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
    tbuf = C2D_TextBufNew(8192);

    cBg = CLR(0, 0, 0);          cCard = CLR(24, 24, 26);   cCard2 = CLR(44, 44, 46);
    cWhite = CLR(255, 255, 255); cMuted = CLR(150, 150, 155); cTrack = CLR(58, 58, 60);
    cBar = CLR(95, 170, 105);    cGoldTxt = CLR(240, 200, 60);
    cSkyTop = CLR(18, 34, 90);   cSkyBot = CLR(52, 100, 170);
    cGold1 = CLR(222, 190, 85);  cGold2 = CLR(206, 172, 70);
    cSideL = CLR(140, 98, 52);   cSideR = CLR(112, 78, 42);  cTrunk = CLR(110, 70, 40);
    cOrange = CLR(236, 128, 40); cRed = CLR(200, 55, 45);    cPine = CLR(70, 150, 80);
    cCloud = CLR(110, 140, 195);

    cfg_load(&cfg);
    loadStats();
    setAccent();
    setTextSize();
    layoutSettings();
    layoutBadges();

    touchPosition tp = {0}, tstart = {0};
    bool dragging = false, moved = false;
    int lastY = 0;
    int frame = 0;
    while (aptMainLoop()) {
        hidScanInput();
        u32 kd = hidKeysDown(), kh = hidKeysHeld(), ku = hidKeysUp();
        if (kd & KEY_START) break;
        if (running && job.done) finishJob();
        if (toastT > 0) toastT--;
        if (resetArm > 0) resetArm--;

        u32 btn = KEY_A | KEY_B | KEY_X | KEY_Y | KEY_SELECT | KEY_L | KEY_R | KEY_DUP | KEY_DDOWN | KEY_DLEFT | KEY_DRIGHT |
                  KEY_CPAD_UP | KEY_CPAD_DOWN | KEY_CPAD_LEFT | KEY_CPAD_RIGHT;
        if (kd & btn) showFocus = true;

        /* ----- touch ----- */
        bool tdown = (kd & KEY_TOUCH) != 0, tup = (ku & KEY_TOUCH) != 0;
        if (tdown) {
            hidTouchRead(&tp);
            tstart = tp; lastY = tp.py; dragging = true; moved = false;
            showFocus = false;
            if (page != P_SETTINGS) focus = defFocus(page);
        } else if (dragging && (kh & KEY_TOUCH)) {
            hidTouchRead(&tp);
            if (abs((int)tp.py - (int)tstart.py) > 6) moved = true;
            if (page == P_SETTINGS && moved) {
                setScroll += lastY - (int)tp.py;
                clampScroll();
            }
            if (scrollPage() && moved) {
                gScroll += lastY - (int)tp.py;
                clampG();
            }
            lastY = tp.py;
        }

        if (tdown && !scrollPage() && page != P_SETTINGS && page != P_HELP) {
            buildRects();
            bool done = false;
            for (int i = 0; i < nfr && !done; i++) {
                if (fr[i].y < 0) continue;
                if (hit(&tp, (int)fr[i].x, (int)fr[i].y, (int)fr[i].w, (int)fr[i].h)) { focus = fr[i].id; activate(fr[i].id); done = true; }
            }
            if (!done && page == P_MENU && hit(&tp, 0, 0, 320, 50)) setPage(P_CHAT);
        }
        if (tdown && page == P_HELP && hit(&tp, 10, 6, 36, 36)) page = P_SETTINGS;
        if (tup && dragging) {
            dragging = false;
            if (scrollPage() && !moved) touchActivate(&tstart);
            if (page == P_SETTINGS && !moved) {
                if (hit(&tstart, 10, 6, 36, 36)) setPage(P_CHAT);
                else for (int i = 0; i < NSET; i++) {
                    float sy = 46 + setY[i] - setScroll;
                    if (SET[i].type == 1 && sy >= 44 && sy + 30 <= 240 && tstart.py >= sy && tstart.py < sy + 30) {
                        setSel = i; settingsActivate(SET[i].id); break;
                    }
                }
            }
        }
        if (!(kh & KEY_TOUCH)) dragging = false;

        /* ----- buttons ----- */
        if (kd & KEY_B) {
            if (page == P_HELP) page = P_SETTINGS;
            else setPage(backOf(page));
        }
        if (kd & KEY_SELECT) setPage(page == P_MENU ? P_CHAT : P_MENU);
        if (kd & KEY_Y) { profTab = 0; setPage(page == P_PROFILE ? P_CHAT : P_PROFILE); }
        if (kd & KEY_X) { newChat(); setPage(P_CHAT); }

        int d = navDir(kh, page != P_CHAT);
        if (d) {
            if (page == P_SETTINGS) settingsMove(d);
            else if (page != P_HELP) { moveFocus(d); keepVisible(); }
        }
        if (page == P_PROFILE && (kd & (KEY_L | KEY_R))) { profTab = !profTab; focus = profTab ? F_P_TAB1 : F_P_TAB0; }

        if (page == P_CHAT) {
            if ((kh & (KEY_DUP | KEY_CSTICK_UP)) && frame % 4 == 0) scrollOff++;
            if ((kh & (KEY_DDOWN | KEY_CSTICK_DOWN)) && frame % 4 == 0 && scrollOff > 0) scrollOff--;
        }
        if (scrollPage() && (kh & (KEY_CSTICK_UP | KEY_CSTICK_DOWN))) {
            gScroll += (kh & KEY_CSTICK_UP) ? -4.0f : 4.0f;
            clampG();
        }
        if (kd & KEY_A) {
            if (page == P_SETTINGS) settingsActivate(SET[setSel].id);
            else if (page == P_HELP) page = P_SETTINGS;
            else { if (!showFocus) focus = defFocus(page); activate(focus); }
        }

        frameNo = frame;
        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        C2D_TextBufClear(tbuf);
        C2D_TargetClear(top, cBg);
        C2D_SceneBegin(top);
        drawTop(frame);
        C2D_TargetClear(bot, cBg);
        C2D_SceneBegin(bot);
        drawBottom();
        C3D_FrameEnd(0);
        frame++;
    }

    camera_close();
    if (th) { threadJoin(th, U64_MAX); threadFree(th); }
    C2D_TextBufDelete(tbuf);
    httpcExit();
    C2D_Fini();
    C3D_Fini();
    gfxExit();
    return 0;
}
