#pragma once
#include <3ds.h>

#define CAM_W 400
#define CAM_H 240

/* Opens the outer (top-LCD) camera. 0 = ok, -1 = unavailable. */
int  camera_open(void);
void camera_close(void);
/* Takes one frame into an internal buffer. 0 = ok. */
int  camera_snap(void);
/* RGB565 pixels of the last snapshot (CAM_W x CAM_H). */
const u16 *camera_frame(void);
/* Writes the last snapshot as a 24-bit BMP. 0 = ok. */
int  camera_save_bmp(const char *path);
