#pragma once
#include <stddef.h>

#define MAX_MSGS 24
#define MSG_LEN  2048

typedef struct { int role; char text[MSG_LEN]; } Msg;   /* role: 0 = user, 1 = assistant */

typedef struct {
    char host[128];    /* e.g. api.example.com (no https://) */
    char path[128];    /* e.g. /v1/chat/completions */
    char key[256];
    char model[96];
    char system[512];
    char name[32];     /* companion name shown in the UI */
    int  verify;       /* 1 = verify TLS certificate */
    int  max_tokens;   /* reply length cap */
} Config;

void cfg_defaults(Config *c);
int  cfg_load(Config *c);            /* 0 = loaded, -1 = template created */
int  cfg_save(const Config *c);      /* 0 = ok */
int  cfg_ready(const Config *c);     /* only host is required; model is optional */
/* Blocking. Returns 0 on success (reply = assistant text) or -1 (reply = error text). */
int  backend_chat(const Config *c, const Msg *msgs, int n, char *reply, size_t cap);

/* Photo/file upload hook. Not implemented until EcoGPT's API exists.
   Returns 0 when the attachment was accepted, -1 with a reason in err otherwise. */
int  backend_send_attachment(const Config *c, const char *path, int is_image, char *err, size_t cap);
