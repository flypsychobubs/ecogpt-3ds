#include "camera.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Untested on hardware: written against libctru's cam.h. */

static bool camUp = false;
static u16 *camBuf = NULL;
static u16 shot[CAM_W * CAM_H];

int camera_open(void)
{
    if (camUp) return 0;
    if (R_FAILED(camInit())) return -1;

    u32 bytes = 0;
    CAMU_SetSize(SELECT_OUT1, SIZE_CTR_TOP_LCD, CONTEXT_A);
    CAMU_SetOutputFormat(SELECT_OUT1, OUTPUT_RGB_565, CONTEXT_A);
    CAMU_SetFrameRate(SELECT_OUT1, FRAME_RATE_15);
    CAMU_SetNoiseFilter(SELECT_OUT1, true);
    CAMU_SetAutoExposure(SELECT_OUT1, true);
    CAMU_SetAutoWhiteBalance(SELECT_OUT1, true);
    CAMU_Activate(SELECT_OUT1);
    CAMU_GetMaxBytes(&bytes, CAM_W, CAM_H);
    CAMU_SetTransferBytes(PORT_CAM1, bytes, CAM_W, CAM_H);

    camBuf = (u16 *)linearAlloc(CAM_W * CAM_H * 2);
    if (!camBuf) { camExit(); return -1; }
    camUp = true;
    return 0;
}

void camera_close(void)
{
    if (!camUp) return;
    camExit();
    linearFree(camBuf);
    camBuf = NULL;
    camUp = false;
}

int camera_snap(void)
{
    if (!camUp) return -1;
    u32 size = CAM_W * CAM_H * 2, bytes = 0;
    CAMU_GetMaxBytes(&bytes, CAM_W, CAM_H);

    CAMU_ClearBuffer(PORT_CAM1);
    CAMU_StartCapture(PORT_CAM1);

    Handle h = 0;
    if (R_FAILED(CAMU_SetReceiving(&h, camBuf, PORT_CAM1, size, (s16)bytes))) {
        CAMU_StopCapture(PORT_CAM1);
        return -1;
    }
    svcWaitSynchronization(h, 2000000000ULL);   /* 2 s timeout */
    svcCloseHandle(h);
    CAMU_StopCapture(PORT_CAM1);

    GSPGPU_InvalidateDataCache(camBuf, size);
    memcpy(shot, camBuf, size);
    return 0;
}

const u16 *camera_frame(void) { return shot; }

int camera_save_bmp(const char *path)
{
    FILE *f = fopen(path, "wb");
    if (!f) return -1;

    int w = CAM_W, h = CAM_H;
    u32 row = (u32)((w * 3 + 3) & ~3), size = row * (u32)h;
    unsigned char hdr[54];
    memset(hdr, 0, sizeof hdr);
    hdr[0] = 'B'; hdr[1] = 'M';
    u32 fsz = 54 + size, off = 54, dsz = 40;
    s32 W = w, H = h;
    u16 planes = 1, bpp = 24;
    memcpy(hdr + 2, &fsz, 4);
    memcpy(hdr + 10, &off, 4);
    memcpy(hdr + 14, &dsz, 4);
    memcpy(hdr + 18, &W, 4);
    memcpy(hdr + 22, &H, 4);
    memcpy(hdr + 26, &planes, 2);
    memcpy(hdr + 28, &bpp, 2);
    memcpy(hdr + 34, &size, 4);
    fwrite(hdr, 1, 54, f);

    unsigned char *line = calloc(1, row);
    if (!line) { fclose(f); return -1; }
    for (int y = h - 1; y >= 0; y--) {
        for (int x = 0; x < w; x++) {
            u16 p = shot[y * w + x];
            line[x * 3 + 0] = (unsigned char)((p & 31) * 255 / 31);
            line[x * 3 + 1] = (unsigned char)(((p >> 5) & 63) * 255 / 63);
            line[x * 3 + 2] = (unsigned char)(((p >> 11) & 31) * 255 / 31);
        }
        fwrite(line, 1, row, f);
    }
    free(line);
    fclose(f);
    return 0;
}
