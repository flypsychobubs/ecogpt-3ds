#include "backend.h"
#include <3ds.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#define CFG_DIR  "sdmc:/3ds/ecogpt"
#define CFG_FILE CFG_DIR "/config.txt"

void cfg_defaults(Config *c)
{
    memset(c, 0, sizeof *c);
    strcpy(c->path, "/v1/chat/completions");
    strcpy(c->system, "You are EcoGPT, a friendly and concise AI assistant. Keep answers short; the user is on a tiny 3DS screen.");
    strcpy(c->name, "Eco");
    c->verify = 1;
    c->max_tokens = 600;
}

static void trim(char *s)
{
    size_t n = strlen(s);
    while (n && (s[n - 1] == '\r' || s[n - 1] == '\n' || s[n - 1] == ' ')) s[--n] = 0;
}

int cfg_load(Config *c)
{
    cfg_defaults(c);
    mkdir("sdmc:/3ds", 0777);
    mkdir(CFG_DIR, 0777);

    FILE *f = fopen(CFG_FILE, "r");
    if (!f) {
        f = fopen(CFG_FILE, "w");
        if (f) {
            fputs("# EcoGPT 3DS config. You can also edit all of this inside the app: Settings > Connection.\n"
                  "# host has no https:// in front. Works with any OpenAI-style chat endpoint.\n"
                  "# model is optional (EcoGPT has no model picker). Leave it empty if the API does not need it.\n"
                  "host=\n"
                  "path=/v1/chat/completions\n"
                  "key=\n"
                  "model=\n"
                  "name=Eco\n"
                  "system=You are EcoGPT, a friendly and concise AI assistant. Keep answers short.\n"
                  "# verify=1 checks the server certificate. If you get a connection error,\n"
                  "# set verify=0 (less safe: your key is sent without certificate checks).\n"
                  "verify=1\n"
                  "max_tokens=600\n", f);
            fclose(f);
        }
        return -1;
    }

    char line[1024];
    while (fgets(line, sizeof line, f)) {
        trim(line);
        if (!line[0] || line[0] == '#') continue;
        char *eq = strchr(line, '=');
        if (!eq) continue;
        *eq = 0;
        const char *k = line, *v = eq + 1;
        if      (!strcmp(k, "host"))   snprintf(c->host,   sizeof c->host,   "%s", v);
        else if (!strcmp(k, "path"))   snprintf(c->path,   sizeof c->path,   "%s", v);
        else if (!strcmp(k, "key"))    snprintf(c->key,    sizeof c->key,    "%s", v);
        else if (!strcmp(k, "model"))  snprintf(c->model,  sizeof c->model,  "%s", v);
        else if (!strcmp(k, "system")) snprintf(c->system, sizeof c->system, "%s", v);
        else if (!strcmp(k, "name"))   snprintf(c->name,   sizeof c->name,   "%s", v);
        else if (!strcmp(k, "verify")) c->verify = atoi(v) != 0;
        else if (!strcmp(k, "max_tokens")) { int t = atoi(v); if (t >= 50 && t <= 4000) c->max_tokens = t; }
    }
    fclose(f);

    if (!strncmp(c->host, "https://", 8)) memmove(c->host, c->host + 8, strlen(c->host + 8) + 1);
    return 0;
}

int cfg_ready(const Config *c) { return c->host[0] != 0; }

int cfg_save(const Config *c)
{
    mkdir("sdmc:/3ds", 0777);
    mkdir(CFG_DIR, 0777);
    FILE *f = fopen(CFG_FILE, "w");
    if (!f) return -1;
    fprintf(f, "# EcoGPT 3DS config (edited from Settings > Connection or by hand).\n"
               "# host has no https:// in front. model is optional.\n"
               "host=%s\npath=%s\nkey=%s\nmodel=%s\nname=%s\nsystem=%s\nverify=%d\nmax_tokens=%d\n",
            c->host, c->path, c->key, c->model, c->name, c->system, c->verify ? 1 : 0, c->max_tokens);
    fclose(f);
    return 0;
}

/* ---------- JSON helpers ---------- */

static size_t jesc(char *d, size_t cap, const char *s)
{
    size_t n = 0;
    for (; *s && n + 7 < cap; s++) {
        unsigned char ch = (unsigned char)*s;
        switch (ch) {
            case '"':  d[n++] = '\\'; d[n++] = '"';  break;
            case '\\': d[n++] = '\\'; d[n++] = '\\'; break;
            case '\n': d[n++] = '\\'; d[n++] = 'n';  break;
            case '\t': d[n++] = '\\'; d[n++] = 't';  break;
            case '\r': break;
            default:
                if (ch >= 0x20) d[n++] = (char)ch;
                break;
        }
    }
    d[n] = 0;
    return n;
}

#define BODY_CAP (96 * 1024)

static void build_body(const Config *c, const Msg *m, int n, char *b)
{
    size_t o = 0, cap = BODY_CAP;
    o += snprintf(b + o, cap - o, "{");
    if (c->model[0]) {
        o += snprintf(b + o, cap - o, "\"model\":\"");
        o += jesc(b + o, cap - o, c->model);
        o += snprintf(b + o, cap - o, "\",");
    }
    o += snprintf(b + o, cap - o, "\"stream\":false,\"max_tokens\":%d,\"messages\":[{\"role\":\"system\",\"content\":\"",
                  c->max_tokens > 0 ? c->max_tokens : 600);
    o += jesc(b + o, cap - o, c->system);
    o += snprintf(b + o, cap - o, "\"}");
    for (int i = 0; i < n; i++) {
        o += snprintf(b + o, cap - o, ",{\"role\":\"%s\",\"content\":\"", m[i].role ? "assistant" : "user");
        o += jesc(b + o, cap - o, m[i].text);
        o += snprintf(b + o, cap - o, "\"}");
    }
    snprintf(b + o, cap - o, "]}");
}

/* Finds choices[0].message.content (OpenAI style) or message.content (native style). */
static int extract_content(const char *json, char *out, size_t cap)
{
    const char *p = strstr(json, "\"message\"");
    if (!p) p = json;
    p = strstr(p, "\"content\"");
    if (!p) return -1;
    p += 9;
    while (*p == ' ' || *p == ':' || *p == '\t') p++;
    if (*p != '"') return -1;
    p++;

    size_t n = 0;
    while (*p && *p != '"' && n + 4 < cap) {
        if (*p == '\\') {
            p++;
            switch (*p) {
                case 'n':  out[n++] = '\n'; break;
                case 't':  out[n++] = ' ';  break;
                case 'r':  break;
                case '"':  out[n++] = '"';  break;
                case '\\': out[n++] = '\\'; break;
                case '/':  out[n++] = '/';  break;
                case 'u': {
                    if (!p[1] || !p[2] || !p[3] || !p[4]) goto done;
                    char h[5] = { p[1], p[2], p[3], p[4], 0 };
                    unsigned cp = (unsigned)strtoul(h, NULL, 16);
                    p += 4;
                    if (cp < 0x80) out[n++] = (char)cp;
                    else if (cp < 0x800) {
                        out[n++] = (char)(0xC0 | (cp >> 6));
                        out[n++] = (char)(0x80 | (cp & 0x3F));
                    } else {
                        out[n++] = (char)(0xE0 | (cp >> 12));
                        out[n++] = (char)(0x80 | ((cp >> 6) & 0x3F));
                        out[n++] = (char)(0x80 | (cp & 0x3F));
                    }
                    break;
                }
                default: if (*p) out[n++] = *p; break;
            }
            if (*p) p++;
        } else {
            out[n++] = *p++;
        }
    }
done:
    out[n] = 0;
    return n ? 0 : -1;
}

/* ---------- HTTPS ---------- */

static int http_post(const Config *c, const char *body, char **out, u32 *status, char *err, size_t errcap)
{
    char url[320];
    snprintf(url, sizeof url, "https://%s%s", c->host, c->path);

    httpcContext ctx;
    Result rc = httpcOpenContext(&ctx, HTTPC_METHOD_POST, url, 1);
    if (R_FAILED(rc)) { snprintf(err, errcap, "Bad URL (0x%08lX). Check host/path in config.txt", (unsigned long)rc); return -1; }

    if (!c->verify) httpcSetSSLOpt(&ctx, SSLCOPT_DisableVerify);
    httpcSetKeepAlive(&ctx, HTTPC_KEEPALIVE_ENABLED);
    httpcAddRequestHeaderField(&ctx, "User-Agent", "ecogpt-3ds/0.1");
    httpcAddRequestHeaderField(&ctx, "Content-Type", "application/json");
    if (c->key[0]) {
        char auth[300];
        snprintf(auth, sizeof auth, "Bearer %s", c->key);
        httpcAddRequestHeaderField(&ctx, "Authorization", auth);
    }
    httpcAddPostDataRaw(&ctx, (const u32 *)body, (u32)strlen(body));

    rc = httpcBeginRequest(&ctx);
    if (R_FAILED(rc)) {
        snprintf(err, errcap, "Connection failed (0x%08lX). If it persists, try verify=0 in config.txt", (unsigned long)rc);
        httpcCloseContext(&ctx);
        return -1;
    }
    httpcGetResponseStatusCode(&ctx, status);

    size_t cap = 16384, size = 0;
    char *buf = malloc(cap);
    if (!buf) { httpcCloseContext(&ctx); snprintf(err, errcap, "Out of memory"); return -1; }

    u32 got = 0;
    do {
        rc = httpcDownloadData(&ctx, (u8 *)buf + size, (u32)(cap - size - 1), &got);
        size += got;
        if (rc == (Result)HTTPC_RESULTCODE_DOWNLOADPENDING) {
            if (cap >= 262144) break;
            cap *= 2;
            char *nb = realloc(buf, cap);
            if (!nb) break;
            buf = nb;
        }
    } while (rc == (Result)HTTPC_RESULTCODE_DOWNLOADPENDING);

    buf[size] = 0;
    httpcCloseContext(&ctx);
    *out = buf;
    return 0;
}

int backend_chat(const Config *c, const Msg *m, int n, char *reply, size_t cap)
{
    if (!cfg_ready(c)) {
        snprintf(reply, cap, "Not set up yet. Open Settings > Connection and set a host.");
        return -1;
    }
    char *body = malloc(BODY_CAP);
    if (!body) { snprintf(reply, cap, "Out of memory"); return -1; }
    build_body(c, m, n, body);

    char *resp = NULL, err[200] = {0};
    u32 status = 0;
    int rc = http_post(c, body, &resp, &status, err, sizeof err);
    free(body);
    if (rc) { snprintf(reply, cap, "%s", err); return -1; }

    if (status < 200 || status >= 300) {
        snprintf(reply, cap, "HTTP %lu: %.140s", (unsigned long)status, resp);
        free(resp);
        return -1;
    }
    rc = extract_content(resp, reply, cap);
    free(resp);
    if (rc) { snprintf(reply, cap, "The reply was empty or in an unexpected format."); return -1; }
    return 0;
}

/* Placeholder: EcoGPT's upload API is not public yet. */
int backend_send_attachment(const Config *c, const char *path, int is_image, char *err, size_t cap)
{
    (void)c; (void)path; (void)is_image;
    snprintf(err, cap, "Photos and files need EcoGPT's API, not available yet.");
    return -1;
}
